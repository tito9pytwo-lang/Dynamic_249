package com.example.island

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import kotlin.math.roundToInt

class CompassSensorManager(
  context: Context,
  private val onCompassUpdated: (CompassState) -> Unit
) : SensorEventListener {

  private val appContext: Context = context.applicationContext ?: context
  private val sensorManager: SensorManager? =
    appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
  private val rotationSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
  private val accelSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
  private val magnetSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

  private val gravity = FloatArray(3)
  private val geomagnetic = FloatArray(3)
  private var hasGravity = false
  private var hasGeomagnetic = false
  private var smoothedAzimuth = 0f
  private var isListening = false
  private var lastEmitMs = 0L

  fun hasCompassSensor(): Boolean =
    rotationSensor != null || (accelSensor != null && magnetSensor != null)

  fun startListening() {
    if (isListening || !hasCompassSensor()) {
      onCompassUpdated(
        CompassState(
          isActive = true,
          azimuthDeg = smoothedAzimuth,
          directionAr = azimuthToArabicDirection(smoothedAzimuth),
          hasSensor = hasCompassSensor()
        )
      )
      return
    }
    try {
      if (rotationSensor != null) {
        sensorManager?.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI)
      } else {
        accelSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        magnetSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
      }
      isListening = true
    } catch (e: Exception) {
      Log.e(TAG, "Failed starting compass sensor listener", e)
    }
  }

  fun stopListening() {
    if (isListening) {
      sensorManager?.unregisterListener(this)
      isListening = false
    }
  }

  override fun onSensorChanged(event: SensorEvent?) {
    if (event == null) return
    var azimuthDeg: Float? = null

    when (event.sensor.type) {
      Sensor.TYPE_ROTATION_VECTOR -> {
        val rotMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
        SensorManager.getOrientation(rotMatrix, orientation)
        val rawDeg = Math.toDegrees(orientation[0].toDouble()).toFloat()
        azimuthDeg = (rawDeg + 360f) % 360f
      }
      Sensor.TYPE_ACCELEROMETER -> {
        System.arraycopy(event.values, 0, gravity, 0, 3)
        hasGravity = true
      }
      Sensor.TYPE_MAGNETIC_FIELD -> {
        System.arraycopy(event.values, 0, geomagnetic, 0, 3)
        hasGeomagnetic = true
      }
    }

    if (azimuthDeg == null && hasGravity && hasGeomagnetic) {
      val r = FloatArray(9)
      val i = FloatArray(9)
      if (SensorManager.getRotationMatrix(r, i, gravity, geomagnetic)) {
        val orientation = FloatArray(3)
        SensorManager.getOrientation(r, orientation)
        val rawDeg = Math.toDegrees(orientation[0].toDouble()).toFloat()
        azimuthDeg = (rawDeg + 360f) % 360f
      }
    }

    if (azimuthDeg != null) {
      val diff = ((azimuthDeg - smoothedAzimuth + 540f) % 360f) - 180f
      smoothedAzimuth = (smoothedAzimuth + diff * 0.25f + 360f) % 360f

      val now = System.currentTimeMillis()
      if (now - lastEmitMs >= 80L) {
        lastEmitMs = now
        onCompassUpdated(
          CompassState(
            isActive = true,
            azimuthDeg = smoothedAzimuth,
            directionAr = azimuthToArabicDirection(smoothedAzimuth),
            hasSensor = true
          )
        )
      }
    }
  }

  override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

  companion object {
    private const val TAG = "CompassSensorManager"

    fun azimuthToArabicDirection(deg: Float): String {
      val norm = ((deg % 360f) + 360f) % 360f
      val index = ((norm + 22.5f) / 45f).toInt() % 8
      return when (index) {
        0 -> "شمال"
        1 -> "شمال شرق"
        2 -> "شرق"
        3 -> "جنوب شرق"
        4 -> "جنوب"
        5 -> "جنوب غرب"
        6 -> "غرب"
        else -> "شمال غرب"
      }
    }
  }
}
