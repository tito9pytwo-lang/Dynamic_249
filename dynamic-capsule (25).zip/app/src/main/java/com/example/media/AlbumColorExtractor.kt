package com.example.media

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import android.graphics.Color as AndroidColor

object AlbumColorExtractor {

  /**
   * Extracts a vibrant, well-lit dominant accent color directly from an album art Bitmap
   * so the Dynamic Capsule border and waveform adapt to the currently playing track.
   */
  fun extractAccentColor(bitmap: Bitmap?, fallback: Color): Color {
    if (bitmap == null || bitmap.isRecycled || bitmap.width <= 0 || bitmap.height <= 0) {
      return fallback
    }

    return try {
      val sampleCols = 12
      val sampleRows = 12
      val stepX = (bitmap.width / sampleCols).coerceAtLeast(1)
      val stepY = (bitmap.height / sampleRows).coerceAtLeast(1)

      val hsv = FloatArray(3)
      var bestColor: Int? = null
      var bestScore = -1f

      var sumR = 0L
      var sumG = 0L
      var sumB = 0L
      var litCount = 0

      var y = stepY / 2
      while (y < bitmap.height) {
        var x = stepX / 2
        while (x < bitmap.width) {
          val pixel = bitmap.getPixel(x, y)
          val alpha = AndroidColor.alpha(pixel)
          if (alpha >= 128) {
            val r = AndroidColor.red(pixel)
            val g = AndroidColor.green(pixel)
            val b = AndroidColor.blue(pixel)
            AndroidColor.RGBToHSV(r, g, b, hsv)

            val sat = hsv[1]
            val value = hsv[2]

            if (value > 0.22f) {
              sumR += r
              sumG += g
              sumB += b
              litCount++
            }

            // Prefer saturated, bright colors that pop cleanly on a #07080A black capsule
            val isNeutralDarkOrWhite = value < 0.22f || (sat < 0.14f && value > 0.88f)
            if (!isNeutralDarkOrWhite) {
              val score = (sat * 2.2f) + (value * 0.9f)
              if (score > bestScore) {
                bestScore = score
                bestColor = pixel
              }
            }
          }
          x += stepX
        }
        y += stepY
      }

      val chosenPixel = bestColor ?: if (litCount > 0) {
        AndroidColor.rgb(
          (sumR / litCount).toInt().coerceIn(0, 255),
          (sumG / litCount).toInt().coerceIn(0, 255),
          (sumB / litCount).toInt().coerceIn(0, 255)
        )
      } else {
        return fallback
      }

      AndroidColor.colorToHSV(chosenPixel, hsv)
      // Ensure the resulting color stays legible on pitch black
      hsv[1] = hsv[1].coerceAtLeast(0.45f)
      hsv[2] = hsv[2].coerceIn(0.68f, 0.98f)
      Color(AndroidColor.HSVToColor(hsv))
    } catch (_: Exception) {
      fallback
    }
  }
}
