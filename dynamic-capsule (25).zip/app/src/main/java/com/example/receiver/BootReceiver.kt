package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.CapsuleSettingsManager
import com.example.island.IslandStateManager
import com.example.service.FloatingCapsuleService
import com.example.service.OverlayCapsuleService

class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
      val settings = CapsuleSettingsManager.getInstance(context).settings.value
      if (!settings.serviceEnabled) return
      if (FloatingCapsuleService.isAccessibilityServiceEnabled(context)) {
        // Android automatically binds enabled AccessibilityServices on boot; initialize island state proactively.
        IslandStateManager.initialize(context)
      } else if (Settings.canDrawOverlays(context)) {
        IslandStateManager.initialize(context)
        try {
          ContextCompat.startForegroundService(context, Intent(context, OverlayCapsuleService::class.java))
        } catch (_: Exception) {
        }
      }
    }
  }
}
