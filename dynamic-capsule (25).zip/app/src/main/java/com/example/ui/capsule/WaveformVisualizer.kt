package com.example.ui.capsule

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun MiniWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  modifier: Modifier = Modifier,
  styleIndex: Int = 0,
  barCount: Int = 4,
  width: Dp = 18.dp,
  height: Dp = 16.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "miniWave")

  val effectiveBars = when (styleIndex) {
    3 -> 6
    2 -> 5
    else -> barCount
  }
  val animValues = List(effectiveBars) { index ->
    val duration = 340 + (index * 115)
    infiniteTransition.animateFloat(
      initialValue = 0.25f,
      targetValue = 1.0f,
      animationSpec = infiniteRepeatable(
        animation = tween(durationMillis = duration, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "bar_$index"
    )
  }

  val wavePhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = (PI * 2).toFloat(),
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 900, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "sine_phase"
  )

  Box(modifier = modifier.width(width).height(height)) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      when (styleIndex) {
        // 1: Smooth Flowing Sine Wave
        1 -> {
          val path = Path()
          val steps = 20
          val midY = size.height / 2f
          val amp = if (isPlaying) size.height * 0.36f else size.height * 0.08f
          for (s in 0..steps) {
            val x = (s.toFloat() / steps) * size.width
            val y = midY + sin((s.toFloat() / steps) * PI * 2.5 + wavePhase).toFloat() * amp
            if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
          }
          drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
          )
        }
        // 2: Sonic Pulse Dots
        2 -> {
          val count = 5
          val stepX = size.width / count
          val midY = size.height / 2f
          for (i in 0 until count) {
            val scale = if (isPlaying) animValues[i].value else 0.35f
            val radius = (size.height * 0.14f + size.height * 0.18f * scale).coerceAtLeast(1.5f)
            drawCircle(
              color = color.copy(alpha = (0.5f + 0.5f * scale).coerceIn(0f, 1f)),
              radius = radius,
              center = Offset(i * stepX + stepX / 2f, midY)
            )
          }
        }
        // 3: Mirror Equalizer Spectrum
        3 -> {
          val count = 6
          val slotW = size.width / count
          val barW = (slotW * 0.55f).coerceAtLeast(1.8f)
          for (i in 0 until count) {
            val mirrorIdx = abs(i - count / 2)
            val raw = if (isPlaying) animValues[i].value else 0.28f
            val boost = (raw * (1f - mirrorIdx * 0.12f)).coerceIn(0.22f, 1f)
            val barH = size.height * boost
            val x = i * slotW + (slotW - barW) / 2f
            val y = (size.height - barH) / 2f
            drawRoundRect(
              color = if (i % 2 == 0) color else Color.White.copy(alpha = 0.85f),
              topLeft = Offset(x, y),
              size = Size(barW, barH),
              cornerRadius = CornerRadius(barW / 2f, barW / 2f)
            )
          }
        }
        // 0: Classic Dynamic Bars
        else -> {
          val totalWidth = size.width
          val totalHeight = size.height
          val barWidth = (totalWidth / (barCount * 2 - 1)).coerceAtLeast(3f)
          val gap = barWidth
          for (i in 0 until barCount) {
            val fraction = if (isPlaying) animValues[i].value else 0.18f
            val barH = (totalHeight * fraction).coerceAtLeast(barWidth)
            val left = i * (barWidth + gap)
            val top = (totalHeight - barH) / 2f
            drawRoundRect(
              color = color,
              topLeft = Offset(left, top),
              size = Size(barWidth, barH),
              cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
          }
        }
      }
    }
  }
}

@Composable
fun ExpandedWaveformVisualizer(
  isPlaying: Boolean,
  color: Color,
  modifier: Modifier = Modifier,
  barCount: Int = 18,
  height: Dp = 28.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "expandedWave")

  val time by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 6.28318f, // 2 * PI
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1800, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "time"
  )

  Box(modifier = modifier.height(height)) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val totalWidth = size.width
      val totalHeight = size.height
      val barSpacing = totalWidth / barCount
      val barWidth = (barSpacing * 0.55f).coerceIn(4f, 10f)

      val brush = Brush.verticalGradient(
        colors = listOf(
          color.copy(alpha = 0.95f),
          color.copy(alpha = 0.45f)
        )
      )

      for (i in 0 until barCount) {
        val fraction = if (isPlaying) {
          // Combination of two sine waves for organic musical spectrum feeling
          val wave1 = sin(time * 2.2f + i * 0.45f) * 0.4f
          val wave2 = sin(time * 1.4f + i * 0.85f) * 0.3f
          (0.35f + wave1 + wave2).coerceIn(0.12f, 1.0f)
        } else {
          // Flat calm resting wave
          0.12f
        }

        val barH = (totalHeight * fraction).coerceAtLeast(barWidth)
        val left = i * barSpacing + (barSpacing - barWidth) / 2f
        val top = (totalHeight - barH) / 2f

        drawRoundRect(
          brush = brush,
          topLeft = Offset(left, top),
          size = Size(barWidth, barH),
          cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
        )
      }
    }
  }
}
