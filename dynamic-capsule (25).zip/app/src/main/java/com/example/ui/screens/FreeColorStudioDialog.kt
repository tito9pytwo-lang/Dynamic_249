package com.example.ui.screens

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CapsuleSettings
import com.example.data.CustomColorSlot
import com.example.ui.theme.AppTheme
import com.example.ui.theme.AppThemePalette
import java.util.Locale

private fun onColorContrast(bg: Color): Color =
  if (bg.luminance() > 0.55f) Color(0xFF121214) else Color.White

private fun slotEffectiveColor(
  slot: CustomColorSlot,
  settings: CapsuleSettings,
  palette: AppThemePalette
): Color {
  val custom = settings.customColorFor(slot)
  if (custom != null) return Color(custom)
  return when (slot) {
    CustomColorSlot.BACKGROUND -> palette.background
    CustomColorSlot.SURFACE -> palette.surface
    CustomColorSlot.ELEVATED -> palette.surfaceElevated
    CustomColorSlot.PRIMARY -> palette.primary
    CustomColorSlot.SECONDARY -> palette.secondary
    CustomColorSlot.TEXT_PRIMARY -> palette.textPrimary
    CustomColorSlot.TEXT_SECONDARY -> palette.textSecondary
    CustomColorSlot.CAPSULE_BG -> Color(0xFF0D0B09)
  }
}

private fun formatHexRgb(color: Color): String {
  val rgb = color.toArgb() and 0xFFFFFF
  return String.format(Locale.US, "#%06X", rgb)
}

@Composable
fun FreeColorStudioDialog(
  settings: CapsuleSettings,
  onToggleCustomColors: (Boolean) -> Unit,
  onUpdateCustomColor: (CustomColorSlot, Int?) -> Unit,
  onResetAllColors: () -> Unit,
  onDismiss: () -> Unit
) {
  val palette = AppTheme.colors
  var selectedSlot by remember { mutableStateOf(CustomColorSlot.PRIMARY) }

  val activeColor = slotEffectiveColor(selectedSlot, settings, palette)
  val hsv = remember { FloatArray(3) }

  var hue by remember { mutableFloatStateOf(36f) }
  var sat by remember { mutableFloatStateOf(0.8f) }
  var value by remember { mutableFloatStateOf(0.9f) }

  LaunchedEffect(selectedSlot, activeColor.toArgb()) {
    AndroidColor.colorToHSV(activeColor.toArgb(), hsv)
    hue = hsv[0].coerceIn(0f, 360f)
    sat = hsv[1].coerceIn(0f, 1f)
    value = hsv[2].coerceIn(0f, 1f)
  }

  val applyHsv: (Float, Float, Float) -> Unit = { h, s, v ->
    hue = h.coerceIn(0f, 360f)
    sat = s.coerceIn(0f, 1f)
    value = v.coerceIn(0.02f, 1f)
    val composed = Color.hsv(hue, sat, value)
    onUpdateCustomColor(selectedSlot, composed.toArgb())
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 20.dp)
        .widthIn(max = 560.dp)
        .testTag("free_color_studio_dialog"),
      shape = RoundedCornerShape(26.dp),
      color = palette.surface,
      border = BorderStroke(1.2.dp, palette.primary.copy(alpha = 0.40f))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Header Row + Master Enable Switch
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(palette.primary.copy(alpha = 0.16f))
                .border(1.dp, palette.primary.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.ColorLens,
                contentDescription = null,
                tint = palette.primary,
                modifier = Modifier.size(22.dp)
              )
            }
            Column {
              Text(
                text = "استوديو الألوان الحر",
                color = palette.textPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "غيّر خلفية التطبيق والأزرار والنصوص والكبسولة بحرية تامة",
                color = palette.textSecondary,
                fontSize = 11.sp
              )
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = palette.textSecondary)
          }
        }

        // Master Custom Mode Toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "تفعيل ألواني المخصصة",
              color = palette.textPrimary,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = if (settings.useCustomColors) "الألوان الحرة مفعلة حالياً على كامل التطبيق" else "تطبيق الثيم الجاهز الافتراضي",
              color = if (settings.useCustomColors) palette.primary else palette.textSecondary,
              fontSize = 11.sp
            )
          }
          Switch(
            checked = settings.useCustomColors,
            onCheckedChange = onToggleCustomColors,
            modifier = Modifier.testTag("custom_colors_master_switch"),
            colors = SwitchDefaults.colors(
              checkedThumbColor = onColorContrast(palette.primary),
              checkedTrackColor = palette.primary
            )
          )
        }

        // Live Interactive Mini App + Capsule Preview
        val previewBg = slotEffectiveColor(CustomColorSlot.BACKGROUND, settings, palette)
        val previewCard = slotEffectiveColor(CustomColorSlot.SURFACE, settings, palette)
        val previewElev = slotEffectiveColor(CustomColorSlot.ELEVATED, settings, palette)
        val previewBtn = slotEffectiveColor(CustomColorSlot.PRIMARY, settings, palette)
        val previewSec = slotEffectiveColor(CustomColorSlot.SECONDARY, settings, palette)
        val previewTxt1 = slotEffectiveColor(CustomColorSlot.TEXT_PRIMARY, settings, palette)
        val previewTxt2 = slotEffectiveColor(CustomColorSlot.TEXT_SECONDARY, settings, palette)
        val previewCap = slotEffectiveColor(CustomColorSlot.CAPSULE_BG, settings, palette)
          .copy(alpha = if (settings.capsuleTransparent) (settings.capsuleOpacityPercent / 100f).coerceIn(0.4f, 0.96f) else 1f)

        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(previewBg)
            .border(1.dp, previewBtn.copy(alpha = 0.40f), RoundedCornerShape(18.dp))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          // Miniature Dynamic Capsule Preview
          Row(
            modifier = Modifier
              .clip(CircleShape)
              .background(previewCap)
              .border(1.2.dp, previewBtn, CircleShape)
              .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(previewSec)
            )
            Text(
              text = if (settings.capsuleTransparent) "كبسولة شفافة (${settings.capsuleOpacityPercent}%)" else "كبسولة معتمة 100%",
              color = Color.White,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Miniature App Card + Primary Button + Secondary Tag
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(previewCard)
              .border(0.9.dp, previewElev, RoundedCornerShape(14.dp))
              .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = "عنوان البطاقة الرئيسية",
                color = previewTxt1,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
              )
              Text(
                text = "معاينة حية للنصوص والخلفيات والأزرار",
                color = previewTxt2,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(previewBtn)
                .padding(horizontal = 12.dp, vertical = 6.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "زر أساسي",
                color = onColorContrast(previewBtn),
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold
              )
            }
          }
        }

        // Target Element Selector Chips (All 8 customizable targets)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = "اختر العنصر الذي تريد تلوينه:",
            color = palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            CustomColorSlot.entries.forEach { slot ->
              val isSelected = selectedSlot == slot
              val slotColor = slotEffectiveColor(slot, settings, palette)
              Row(
                modifier = Modifier
                  .testTag("color_slot_${slot.name.lowercase()}")
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (isSelected) palette.primary.copy(alpha = 0.16f) else palette.surfaceElevated)
                  .border(
                    width = if (isSelected) 1.3.dp else 0.9.dp,
                    color = if (isSelected) palette.primary else palette.border,
                    shape = RoundedCornerShape(12.dp)
                  )
                  .clickable { selectedSlot = slot }
                  .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Box(
                  modifier = Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(slotColor)
                    .border(1.dp, palette.textPrimary.copy(alpha = 0.45f), CircleShape)
                )
                Text(
                  text = slot.labelAr,
                  color = if (isSelected) palette.primary else palette.textPrimary,
                  fontSize = 11.sp,
                  fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                )
              }
            }
          }
        }

        HorizontalDivider(color = palette.border)

        // Current Slot Color Hex + Interactive Hue / Saturation / Brightness Spectrum Pickers
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(activeColor)
                .border(1.2.dp, palette.textPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            )
            Column {
              Text(selectedSlot.labelAr, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              Text(formatHexRgb(activeColor), color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
          }
          TextButton(
            onClick = { onUpdateCustomColor(selectedSlot, null) },
            enabled = settings.customColorFor(selectedSlot) != null
          ) {
            Icon(
              imageVector = Icons.Default.RestartAlt,
              contentDescription = null,
              tint = if (settings.customColorFor(selectedSlot) != null) palette.warning else palette.textMuted,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "افتراضي العنصر",
              color = if (settings.customColorFor(selectedSlot) != null) palette.warning else palette.textMuted,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // 1. Rainbow Hue Spectrum Bar
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text("درجة اللون (Hue)", color = palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
          HueSpectrumBar(
            hue = hue,
            onHueChange = { newHue -> applyHsv(newHue, sat, value) }
          )
        }

        // 2. Saturation Slider
        Column {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("التشبع (Saturation)", color = palette.textSecondary, fontSize = 11.sp)
            Text("${(sat * 100).toInt()}%", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = sat,
            onValueChange = { applyHsv(hue, it, value) },
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(
              thumbColor = Color.hsv(hue, sat, value),
              activeTrackColor = Color.hsv(hue, 1f, 0.9f),
              inactiveTrackColor = palette.sliderInactiveTrack
            )
          )
        }

        // 3. Brightness / Value Slider
        Column {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("السطوع والعمق (Brightness)", color = palette.textSecondary, fontSize = 11.sp)
            Text("${(value * 100).toInt()}%", color = palette.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = value,
            onValueChange = { applyHsv(hue, sat, it) },
            valueRange = 0.02f..1f,
            colors = SliderDefaults.colors(
              thumbColor = Color.hsv(hue, sat, value),
              activeTrackColor = Color.hsv(hue, sat, 1f),
              inactiveTrackColor = palette.sliderInactiveTrack
            )
          )
        }

        // Quick 1-Tap Popular Swatches Row
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("ألوان سريعة مقترحة:", color = palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
          val quickSwatches = listOf(
            Color(0xFF000000), // Pure Black OLED
            Color(0xFF0E0C0A), // Deep Obsidian
            Color(0xFF181512), // Smoked Card
            Color(0xFF0B1426), // Midnight Navy
            Color(0xFFF6F2EA), // Warm Cream Light
            Color(0xFFFFFFFF), // Pure White
            Color(0xFFF59E0B), // Amber Gold
            Color(0xFF10B981), // Emerald
            Color(0xFF38BDF8), // Sky Glass
            Color(0xFFFF2D55), // Crimson Red
            Color(0xFFFF6B6B), // Coral Peach
            Color(0xFFA78BFA)  // Soft Violet
          )
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            quickSwatches.forEach { swatch ->
              val isCurrent = (swatch.toArgb() and 0xFFFFFF) == (activeColor.toArgb() and 0xFFFFFF)
              Box(
                modifier = Modifier
                  .size(30.dp)
                  .clip(CircleShape)
                  .background(swatch)
                  .border(
                    width = if (isCurrent) 2.5.dp else 1.dp,
                    color = if (isCurrent) palette.primary else palette.textSecondary.copy(alpha = 0.5f),
                    shape = CircleShape
                  )
                  .clickable { onUpdateCustomColor(selectedSlot, swatch.toArgb()) }
              )
            }
          }
        }

        // Bottom Actions: Reset All + Done
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = onResetAllColors,
            modifier = Modifier
              .weight(1f)
              .testTag("reset_all_custom_colors_button"),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, palette.error.copy(alpha = 0.6f)),
            contentPadding = PaddingValues(vertical = 12.dp)
          ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null, tint = palette.error, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("إرجاع الكل", color = palette.error, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1.3f)
              .testTag("apply_custom_colors_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = palette.primary,
              contentColor = onColorContrast(palette.primary)
            ),
            contentPadding = PaddingValues(vertical = 12.dp)
          ) {
            Text("تطبيق وإغلاق", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
          }
        }
      }
    }
  }
}

@Composable
private fun HueSpectrumBar(
  hue: Float,
  onHueChange: (Float) -> Unit
) {
  var barWidthPx by remember { mutableFloatStateOf(1f) }
  val spectrumColors = remember {
    listOf(
      Color.hsv(0f, 1f, 1f),
      Color.hsv(60f, 1f, 1f),
      Color.hsv(120f, 1f, 1f),
      Color.hsv(180f, 1f, 1f),
      Color.hsv(240f, 1f, 1f),
      Color.hsv(300f, 1f, 1f),
      Color.hsv(360f, 1f, 1f)
    )
  }

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .height(34.dp)
      .clip(RoundedCornerShape(14.dp))
      .onSizeChanged { barWidthPx = it.width.toFloat().coerceAtLeast(1f) }
      .pointerInput(Unit) {
        detectTapGestures { offset ->
          val frac = (offset.x / barWidthPx).coerceIn(0f, 1f)
          onHueChange(frac * 360f)
        }
      }
      .pointerInput(Unit) {
        detectDragGestures { change, _ ->
          change.consume()
          val frac = (change.position.x / barWidthPx).coerceIn(0f, 1f)
          onHueChange(frac * 360f)
        }
      }
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawRoundRect(
        brush = Brush.horizontalGradient(spectrumColors),
        cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
      )
      val thumbX = ((hue.coerceIn(0f, 360f) / 360f) * size.width).coerceIn(10.dp.toPx(), size.width - 10.dp.toPx())
      val center = Offset(thumbX, size.height / 2f)
      drawCircle(color = Color.White, radius = 11.dp.toPx(), center = center)
      drawCircle(color = Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f), radius = 7.5.dp.toPx(), center = center)
    }
  }
}
