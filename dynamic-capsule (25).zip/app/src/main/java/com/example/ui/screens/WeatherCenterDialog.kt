package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CapsuleSettings
import com.example.island.WeatherRepository
import com.example.island.WeatherState
import com.example.ui.capsule.SolarArcCanvas
import com.example.ui.capsule.weatherIconAndColor
import com.example.ui.theme.AppTheme
import kotlinx.coroutines.delay

@Composable
fun WeatherCenterDialog(
  weatherState: WeatherState,
  settings: CapsuleSettings,
  onSelectSuggestion: (WeatherRepository.CitySuggestion) -> Unit,
  onSearchCityQuery: (String) -> Unit,
  onRenameDisplayCity: (String) -> Unit,
  onDeleteCity: () -> Unit,
  onRefreshNow: () -> Unit,
  onShowInCapsule: () -> Unit,
  onDismiss: () -> Unit
) {
  val palette = AppTheme.colors
  val primaryText = palette.textPrimary
  val secondaryText = palette.textSecondary
  val mutedText = palette.textMuted
  val buttonTextOnPrimary = if (palette.primary.luminance() > 0.55f) Color(0xFF121214) else Color.White

  var searchInput by remember(settings.weatherCityQuery) {
    mutableStateOf(settings.weatherCityQuery)
  }
  var aliasInput by remember(settings.weatherCityDisplayAlias, weatherState.actualCityName) {
    mutableStateOf(settings.weatherCityDisplayAlias)
  }
  var suggestions by remember { mutableStateOf<List<WeatherRepository.CitySuggestion>>(emptyList()) }
  var isSearchingSuggestions by remember { mutableStateOf(false) }
  var suggestionError by remember { mutableStateOf<String?>(null) }

  // Live debounced city autocomplete prediction via Open-Meteo Geocoding API
  LaunchedEffect(searchInput) {
    val clean = searchInput.trim()
    if (clean.length < 2) {
      suggestions = emptyList()
      isSearchingSuggestions = false
      suggestionError = null
      return@LaunchedEffect
    }
    isSearchingSuggestions = true
    suggestionError = null
    delay(280)
    WeatherRepository.searchCitySuggestions(clean)
      .onSuccess { list ->
        suggestions = list
        isSearchingSuggestions = false
      }
      .onFailure {
        suggestions = emptyList()
        isSearchingSuggestions = false
        suggestionError = "تعذر جلب اقتراحات المدن حالياً"
      }
  }

  val (wIcon, wTint) = weatherIconAndColor(
    weatherCode = weatherState.weatherCode,
    isDay = weatherState.isDay,
    isWarning = weatherState.isWarning
  )

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 20.dp)
        .testTag("weather_center_dialog"),
      shape = RoundedCornerShape(26.dp),
      color = palette.surface,
      border = BorderStroke(1.2.dp, palette.border)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(max = 680.dp)
          .verticalScroll(rememberScrollState())
          .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Header Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(palette.warning.copy(alpha = 0.16f))
                .border(1.dp, palette.warning.copy(alpha = 0.42f), RoundedCornerShape(12.dp)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.WbSunny, contentDescription = null, tint = palette.warning, modifier = Modifier.size(20.dp))
            }
            Column {
              Text(
                text = "نافذة الطقس والمدن المباشرة",
                color = primaryText,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold
              )
              Text(
                text = "تنبؤ تلقائي بالمدينة • تحديث فعلي عبر Open-Meteo",
                color = secondaryText,
                fontSize = 11.sp
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = secondaryText)
          }
        }

        // Live Weather Telemetry Card
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, wTint.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            .padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(wIcon, contentDescription = null, tint = wTint, modifier = Modifier.size(28.dp))
              Column {
                Text(
                  text = if (weatherState.isLoaded) "${weatherState.cityName} • ${weatherState.temperatureC}°C"
                  else if (weatherState.isLoading) "جاري تحميل الطقس..."
                  else "لم يتم تحميل الطقس بعد",
                  color = primaryText,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.ExtraBold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = when {
                    weatherState.isLoaded -> buildString {
                      append(weatherState.conditionAr)
                      if (weatherState.actualCityName.isNotBlank() && weatherState.actualCityName != weatherState.cityName) {
                        append(" (الأصل: ${weatherState.actualCityName})")
                      }
                    }
                    !weatherState.errorMessage.isNullOrBlank() -> weatherState.errorMessage
                    else -> "اختر مدينة أو فعّل الموقع"
                  },
                  color = if (!weatherState.errorMessage.isNullOrBlank() && !weatherState.isLoaded) palette.error else secondaryText,
                  fontSize = 11.sp
                )
              }
            }

            IconButton(
              onClick = onRefreshNow,
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(palette.primary.copy(alpha = 0.14f))
            ) {
              Icon(Icons.Default.Refresh, contentDescription = "تحديث الآن", tint = palette.primary, modifier = Modifier.size(18.dp))
            }
          }

          if (weatherState.isLoaded) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(palette.success.copy(alpha = 0.14f))
                  .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = palette.success, modifier = Modifier.size(13.dp))
                Text(
                  text = if (weatherState.resolvedCoordinatesLabel.isNotBlank())
                    "إحداثيات حقيقية: ${weatherState.resolvedCoordinatesLabel}"
                  else "بيانات حية محدثة",
                  color = palette.success,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                )
              }

              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .background(palette.surface)
                  .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(Icons.Default.WaterDrop, contentDescription = null, tint = palette.primary, modifier = Modifier.size(12.dp))
                Text("${weatherState.humidityPct}%", color = primaryText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Icon(Icons.Default.Air, contentDescription = null, tint = secondaryText, modifier = Modifier.size(12.dp))
                Text("${weatherState.windSpeedKmh} كم/س", color = primaryText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }

            // Sunrise / Sunset live solar arc preview
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
            ) {
              SolarArcCanvas(
                progress = weatherState.sunriseProgress,
                isDay = weatherState.isDay,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(52.dp)
              )
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .align(Alignment.BottomCenter)
                  .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("الشروق ${weatherState.sunriseText}", color = mutedText, fontSize = 10.sp)
                Text("الغروب ${weatherState.sunsetText}", color = mutedText, fontSize = 10.sp)
              }
            }

            if (weatherState.hourlyForecast.isNotEmpty()) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .background(palette.surface)
                  .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                weatherState.hourlyForecast.take(6).forEach { item ->
                  val hourNum = item.hourLabel.take(2).toIntOrNull() ?: 12
                  val (hIcon, hColor) = weatherIconAndColor(item.weatherCode, isDay = hourNum in 6..18)
                  Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(item.hourLabel, color = secondaryText, fontSize = 9.sp)
                    Icon(hIcon, contentDescription = null, tint = hColor, modifier = Modifier.size(15.dp))
                    Text("${item.tempC}°", color = primaryText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }

        // City Search & Live Autocomplete Predictions
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, palette.border, RoundedCornerShape(16.dp))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = palette.primary, modifier = Modifier.size(16.dp))
            Text(
              text = "ابحث عن مدينة (مع التنبؤ التلقائي)",
              color = primaryText,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = searchInput,
              onValueChange = { searchInput = it },
              placeholder = { Text("اكتب اسم المدينة بالعربي أو الإنجليزي...", fontSize = 11.sp, color = mutedText) },
              singleLine = true,
              trailingIcon = {
                if (isSearchingSuggestions) {
                  CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = palette.primary)
                } else if (searchInput.isNotEmpty()) {
                  IconButton(onClick = {
                    searchInput = ""
                    suggestions = emptyList()
                  }) {
                    Icon(Icons.Default.Close, contentDescription = "مسح البحث", tint = mutedText, modifier = Modifier.size(16.dp))
                  }
                }
              },
              modifier = Modifier
                .weight(1f)
                .testTag("weather_city_search_input"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.primary,
                unfocusedBorderColor = palette.border,
                focusedTextColor = primaryText,
                unfocusedTextColor = primaryText
              )
            )

            Button(
              onClick = {
                onSearchCityQuery(searchInput)
                suggestions = emptyList()
              },
              colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = buttonTextOnPrimary),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
            ) {
              Text("بحث", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }

          // Live Predicted City Suggestions Dropdown
          AnimatedVisibility(visible = suggestions.isNotEmpty() || suggestionError != null) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(palette.surface)
                .border(1.dp, palette.primary.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
              verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              if (suggestionError != null) {
                Text(
                  text = suggestionError!!,
                  color = palette.warning,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(10.dp)
                )
              } else {
                Text(
                  text = "اختر المدينة المطابقة:",
                  color = palette.primary,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
                suggestions.take(6).forEachIndexed { idx, suggestion ->
                  if (idx > 0) {
                    HorizontalDivider(color = palette.border.copy(alpha = 0.5f), thickness = 0.6.dp)
                  }
                  Row(
                    modifier = Modifier
                      .fillMaxWidth()
                      .clickable {
                        searchInput = suggestion.name
                        suggestions = emptyList()
                        onSelectSuggestion(suggestion)
                      }
                      .padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                      modifier = Modifier.weight(1f)
                    ) {
                      Icon(Icons.Default.LocationOn, contentDescription = null, tint = palette.primary, modifier = Modifier.size(16.dp))
                      Column {
                        Text(
                          text = suggestion.name,
                          color = primaryText,
                          fontSize = 12.sp,
                          fontWeight = FontWeight.Bold
                        )
                        val sub = suggestion.displaySubtitle()
                        if (sub.isNotBlank()) {
                          Text(
                            text = sub,
                            color = secondaryText,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                          )
                        }
                      }
                    }
                    Text(
                      text = suggestion.coordinatesLabel(),
                      color = mutedText,
                      fontSize = 9.sp
                    )
                  }
                }
              }
            }
          }

          // Quick-pick popular cities
          val quickCities = remember {
            listOf("الرياض", "جدة", "القاهرة", "دبي", "طرابلس", "جنزور", "عمّان", "الدوحة", "الرباط", "إسطنبول", "لندن")
          }
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            quickCities.forEach { city ->
              val isActive = settings.weatherCityQuery.equals(city, ignoreCase = true)
              Box(
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (isActive) palette.primary.copy(alpha = 0.22f) else palette.surface)
                  .border(
                    width = 1.dp,
                    color = if (isActive) palette.primary else palette.border,
                    shape = CircleShape
                  )
                  .clickable {
                    searchInput = city
                    suggestions = emptyList()
                    onSearchCityQuery(city)
                  }
                  .padding(horizontal = 10.dp, vertical = 5.dp)
              ) {
                Text(
                  text = city,
                  color = if (isActive) palette.primary else secondaryText,
                  fontSize = 11.sp,
                  fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Medium
                )
              }
            }
          }
        }

        // Rename Display Name & Delete Selected City
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, palette.border, RoundedCornerShape(16.dp))
            .padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.Edit, contentDescription = null, tint = palette.secondary, modifier = Modifier.size(16.dp))
            Text(
              text = "تعديل أو حذف اسم المدينة",
              color = primaryText,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = aliasInput,
              onValueChange = { aliasInput = it },
              placeholder = { Text("تعديل الاسم المعروض (اختياري)...", fontSize = 11.sp, color = mutedText) },
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("weather_city_alias_input"),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = palette.secondary,
                unfocusedBorderColor = palette.border,
                focusedTextColor = primaryText,
                unfocusedTextColor = primaryText
              )
            )

            Button(
              onClick = { onRenameDisplayCity(aliasInput) },
              modifier = Modifier.testTag("rename_weather_city_button"),
              colors = ButtonDefaults.buttonColors(
                containerColor = palette.secondary,
                contentColor = if (palette.secondary.luminance() > 0.55f) Color(0xFF121214) else Color.White
              ),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
            ) {
              Text("تغيير الاسم", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            if (settings.weatherCityDisplayAlias.isNotBlank()) {
              OutlinedButton(
                onClick = {
                  aliasInput = ""
                  onRenameDisplayCity("")
                },
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, palette.secondary.copy(alpha = 0.5f))
              ) {
                Text("استعادة الاسم الأصلي", color = palette.secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            OutlinedButton(
              onClick = {
                searchInput = ""
                aliasInput = ""
                suggestions = emptyList()
                onDeleteCity()
              },
              modifier = Modifier
                .weight(1f)
                .testTag("delete_weather_city_button"),
              border = BorderStroke(1.dp, palette.error.copy(alpha = 0.55f)),
              colors = ButtonDefaults.outlinedButtonColors(
                containerColor = palette.error.copy(alpha = 0.12f),
                contentColor = palette.error
              )
            ) {
              Icon(
                imageVector = if (settings.hasCustomWeatherCity) Icons.Default.Delete else Icons.Default.MyLocation,
                contentDescription = null,
                tint = palette.error,
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (settings.hasCustomWeatherCity) "حذف المدينة والعودة لموقعي" else "تحديد موقعي التلقائي",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // Bottom Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Button(
            onClick = {
              onShowInCapsule()
              onDismiss()
            },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = palette.primary, contentColor = buttonTextOnPrimary),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("عرض بالكبسولة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          TextButton(onClick = onDismiss) {
            Text("إغلاق", color = secondaryText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
