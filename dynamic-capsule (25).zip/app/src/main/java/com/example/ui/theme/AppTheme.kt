package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.CapsuleSettings
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AppThemeOption(
  val index: Int,
  val titleAr: String,
  val subtitleAr: String,
  val badgeAr: String,
  val previewBg: Color,
  val previewCard: Color,
  val previewAccent: Color
) {
  CLASSIC_DARK(
    index = 0,
    titleAr = "أوبسيديان الكهرماني",
    subtitleAr = "فحمي دافئ مع ذهب كهرماني ولمسات زمردية راقية",
    badgeAr = "Obsidian Gold",
    previewBg = ObsidianBackground,
    previewCard = ObsidianCardBackground,
    previewAccent = ObsidianPrimary
  ),
  IPHONE_LIQUID_GLASS(
    index = 1,
    titleAr = "زجاج آيفون 26",
    subtitleAr = "الزجاج السائل الشفاف الرائج بإضاءة وانعكاس حي",
    badgeAr = "Liquid Glass",
    previewBg = Color(0xFF060A16),
    previewCard = Color(0x96141C30),
    previewAccent = Color(0xFF38BDF8)
  ),
  IPHONE_LIGHT_FROST(
    index = 2,
    titleAr = "زجاج الكريستال النهاري",
    subtitleAr = "بلور رملي دافئ بإضاءة كهرمانية وزمرّدية",
    badgeAr = "Warm Frost",
    previewBg = Color(0xFFF3ECE0),
    previewCard = Color(0xCCFFFDF8),
    previewAccent = SandstoneLightPrimary
  ),
  CYBER_NEON(
    index = 3,
    titleAr = "زمرد الغابة والبرونز",
    subtitleAr = "أوبسيديان زمردي عميق مع تباين برونزي حاد",
    badgeAr = "Forest Emerald",
    previewBg = Color(0xFF07130E),
    previewCard = Color(0xCC10221A),
    previewAccent = ObsidianSecondary
  ),
  AURORA_LIGHT(
    index = 4,
    titleAr = "العاج الرملي",
    subtitleAr = "الوضع الفاتح الدافئ بأسلوب الورق التحريري",
    badgeAr = "Sandstone",
    previewBg = SandstoneLightBackground,
    previewCard = SandstoneLightCardBackground,
    previewAccent = SandstoneLightPrimary
  ),
  OLD_CLASSIC(
    index = 5,
    titleAr = "التصميم القديم الكلاسيكي",
    subtitleAr = "التصميم الأصلي السابق للتطبيق باللون الكحلي والأخضر",
    badgeAr = "Classic Old",
    previewBg = Color(0xFF0A0D14),
    previewCard = Color(0xFF141926),
    previewAccent = Color(0xFF22C55E)
  ),
  NOTHING_MONO(
    index = 6,
    titleAr = "مونو ستوديو (Nothing)",
    subtitleAr = "ترند السوشيال ميديا: أسود OLED مع أبيض ناصع ونقطة حمراء",
    badgeAr = "Trending • Mono",
    previewBg = Color(0xFF000000),
    previewCard = Color(0xFF141416),
    previewAccent = Color(0xFFFF2D55)
  ),
  SUNSET_CREATOR(
    index = 7,
    titleAr = "غروب إنستغرام (Coral)",
    subtitleAr = "ألوان ريلز التصميم الحديثة: خوخ مرجاني ودفء برونزي",
    badgeAr = "Trending • Sunset",
    previewBg = Color(0xFF140D10),
    previewCard = Color(0xFF22171B),
    previewAccent = Color(0xFFFF6B6B)
  ),
  NORDIC_MATCHA(
    index = 8,
    titleAr = "ماتشا التحريري (Dribbble)",
    subtitleAr = "تصميم سوشيال ميديا فاتح ناعم بلون الماتشا والمرجان",
    badgeAr = "Trending • Matcha",
    previewBg = Color(0xFFF1F4EE),
    previewCard = Color(0xFFFFFFFF),
    previewAccent = Color(0xFF1D7A5F)
  );

  companion object {
    fun fromIndex(index: Int): AppThemeOption =
      entries.firstOrNull { it.index == index } ?: CLASSIC_DARK
  }
}

enum class CardVariant {
  HERO_PREVIEW,
  STUDIO_CREATIVE,
  UTILITY_COMPACT,
  STATUS_REACTIVE,
  CONTROL_PANEL
}

data class AppThemePalette(
  val option: AppThemeOption,
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val primary: Color,
  val secondary: Color,
  val tertiary: Color,
  val success: Color,
  val warning: Color,
  val error: Color,
  val border: Color,
  val specularTopLeft: Color,
  val specularBottomRight: Color,
  val glossHighlight: Color,
  val heroGradientStart: Color,
  val heroGradientEnd: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textMuted: Color,
  val navBarContainer: Color,
  val splashGlowA: Color,
  val splashGlowB: Color,
  val dividerColor: Color,
  val sliderInactiveTrack: Color,
  val isLightOverride: Boolean? = null,
  val isCustomActive: Boolean = false
) {
  val isGlass: Boolean
    get() = option == AppThemeOption.IPHONE_LIQUID_GLASS ||
      option == AppThemeOption.IPHONE_LIGHT_FROST ||
      option == AppThemeOption.CYBER_NEON

  val isLight: Boolean
    get() = isLightOverride ?: (
      option == AppThemeOption.IPHONE_LIGHT_FROST ||
        option == AppThemeOption.AURORA_LIGHT ||
        option == AppThemeOption.NORDIC_MATCHA
      )
}

fun AppThemePalette.withCustomOverrides(settings: CapsuleSettings?): AppThemePalette {
  if (settings == null || !settings.useCustomColors) return this
  val bg = settings.customBackgroundColor?.let { Color(it) } ?: background
  val surf = settings.customSurfaceColor?.let { Color(it) } ?: surface
  val elev = settings.customElevatedColor?.let { Color(it) } ?: surfaceElevated
  val prim = settings.customPrimaryColor?.let { Color(it) } ?: primary
  val sec = settings.customSecondaryColor?.let { Color(it) } ?: secondary
  val txtPrim = settings.customTextPrimaryColor?.let { Color(it) } ?: textPrimary
  val txtSec = settings.customTextSecondaryColor?.let { Color(it) } ?: textSecondary

  val customLight = bg.luminance() > 0.52f
  val derivedBorder = lerp(elev, txtPrim, if (customLight) 0.16f else 0.14f)
  val derivedNav = if (settings.customBackgroundColor != null || settings.customElevatedColor != null) {
    lerp(bg, elev, 0.45f)
  } else {
    navBarContainer
  }

  return copy(
    background = bg,
    surface = surf,
    surfaceElevated = elev,
    primary = prim,
    secondary = sec,
    textPrimary = txtPrim,
    textSecondary = txtSec,
    textMuted = lerp(txtSec, bg, 0.28f),
    border = derivedBorder,
    dividerColor = derivedBorder.copy(alpha = 0.65f),
    navBarContainer = derivedNav,
    heroGradientStart = lerp(surf, prim, 0.14f),
    heroGradientEnd = surf,
    specularTopLeft = if (customLight) Color.White.copy(alpha = 0.85f) else txtPrim.copy(alpha = 0.22f),
    specularBottomRight = derivedBorder,
    splashGlowA = prim.copy(alpha = 0.24f),
    splashGlowB = sec.copy(alpha = 0.18f),
    sliderInactiveTrack = lerp(elev, prim, 0.22f),
    isLightOverride = customLight,
    isCustomActive = true
  )
}

val ClassicDarkPalette = AppThemePalette(
  option = AppThemeOption.CLASSIC_DARK,
  background = ObsidianBackground,
  surface = ObsidianCardBackground,
  surfaceElevated = ObsidianElevatedSurface,
  primary = ObsidianPrimary,
  secondary = ObsidianSecondary,
  tertiary = ObsidianTertiary,
  success = ObsidianSuccess,
  warning = ObsidianWarning,
  error = ObsidianError,
  border = ObsidianBorder,
  specularTopLeft = Color(0x40FFF4E0),
  specularBottomRight = Color(0x14352D24),
  glossHighlight = Color(0x0EFFF6E6),
  heroGradientStart = Color(0xFF231C14),
  heroGradientEnd = ObsidianCardBackground,
  textPrimary = ObsidianTextPrimary,
  textSecondary = ObsidianTextSecondary,
  textMuted = ObsidianTextMuted,
  navBarContainer = Color(0xFF171410),
  splashGlowA = ObsidianPrimary.copy(alpha = 0.24f),
  splashGlowB = ObsidianSecondary.copy(alpha = 0.16f),
  dividerColor = ObsidianBorder,
  sliderInactiveTrack = Color(0xFF332B22)
)

val AuroraLightPalette = AppThemePalette(
  option = AppThemeOption.AURORA_LIGHT,
  background = SandstoneLightBackground,
  surface = SandstoneLightCardBackground,
  surfaceElevated = SandstoneLightElevatedSurface,
  primary = SandstoneLightPrimary,
  secondary = SandstoneLightSecondary,
  tertiary = SandstoneLightTertiary,
  success = SandstoneLightSuccess,
  warning = SandstoneLightWarning,
  error = SandstoneLightError,
  border = SandstoneLightBorder,
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = SandstoneLightBorder,
  glossHighlight = Color(0x33FFFDF8),
  heroGradientStart = Color(0xFFFFFDF9),
  heroGradientEnd = Color(0xFFF3E9D8),
  textPrimary = SandstoneLightTextPrimary,
  textSecondary = SandstoneLightTextSecondary,
  textMuted = SandstoneLightTextMuted,
  navBarContainer = Color(0xFFFFFDF9),
  splashGlowA = SandstoneLightPrimary.copy(alpha = 0.16f),
  splashGlowB = SandstoneLightSecondary.copy(alpha = 0.14f),
  dividerColor = SandstoneLightBorder,
  sliderInactiveTrack = Color(0xFFD5C8B4)
)

val IphoneLiquidGlassPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIQUID_GLASS,
  background = Color(0xFF060913),
  surface = Color(0x92151E32),
  surfaceElevated = Color(0x881F2B46),
  primary = Color(0xFF38BDF8),
  secondary = Color(0xFFA78BFA),
  tertiary = Color(0xFFFB7185),
  success = Color(0xFF22C55E),
  warning = Color(0xFFF59E0B),
  error = Color(0xFFF87171),
  border = Color(0x5293C5FD),
  specularTopLeft = Color(0x99FFFFFF),
  specularBottomRight = Color(0x6638BDF8),
  glossHighlight = Color(0x24FFFFFF),
  heroGradientStart = Color(0xBD1B2742),
  heroGradientEnd = Color(0x92141C30),
  textPrimary = Color(0xFFF8FAFF),
  textSecondary = Color(0xFFAEBAD3),
  textMuted = Color(0xFF7B89A6),
  navBarContainer = Color(0xD80D1324),
  splashGlowA = Color(0xFF38BDF8).copy(alpha = 0.30f),
  splashGlowB = Color(0xFFA78BFA).copy(alpha = 0.24f),
  dividerColor = Color(0x2EFFFFFF),
  sliderInactiveTrack = Color(0x40FFFFFF)
)

val IphoneLightFrostPalette = AppThemePalette(
  option = AppThemeOption.IPHONE_LIGHT_FROST,
  background = Color(0xFFF2EBE0),
  surface = Color(0xD4FFFDF9),
  surfaceElevated = Color(0xBFEFE5D5),
  primary = SandstoneLightPrimary,
  secondary = SandstoneLightSecondary,
  tertiary = SandstoneLightTertiary,
  success = SandstoneLightSuccess,
  warning = SandstoneLightWarning,
  error = SandstoneLightError,
  border = Color(0xB3FFFDF8),
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = Color(0x55C26D00),
  glossHighlight = Color(0x55FFFFFF),
  heroGradientStart = Color(0xEDFFFDF9),
  heroGradientEnd = Color(0xD4F4E9D7),
  textPrimary = SandstoneLightTextPrimary,
  textSecondary = SandstoneLightTextSecondary,
  textMuted = SandstoneLightTextMuted,
  navBarContainer = Color(0xE8FFFDF9),
  splashGlowA = SandstoneLightPrimary.copy(alpha = 0.20f),
  splashGlowB = SandstoneLightSecondary.copy(alpha = 0.18f),
  dividerColor = Color(0x221E1915),
  sliderInactiveTrack = Color(0x33C26D00)
)

val CyberNeonPalette = AppThemePalette(
  option = AppThemeOption.CYBER_NEON,
  background = Color(0xFF07120D),
  surface = Color(0xCC0F2119),
  surfaceElevated = Color(0xBF162E23),
  primary = ObsidianSecondary,
  secondary = ObsidianPrimary,
  tertiary = ObsidianTertiary,
  success = ObsidianSuccess,
  warning = ObsidianWarning,
  error = ObsidianError,
  border = Color(0x5510B981),
  specularTopLeft = Color(0x9910B981),
  specularBottomRight = Color(0x88F59E0B),
  glossHighlight = Color(0x1A10B981),
  heroGradientStart = Color(0xD6153023),
  heroGradientEnd = Color(0xCC0F2119),
  textPrimary = Color(0xFFF2FBF7),
  textSecondary = Color(0xFFA7C7B8),
  textMuted = Color(0xFF6F9484),
  navBarContainer = Color(0xDE0B1913),
  splashGlowA = ObsidianSecondary.copy(alpha = 0.26f),
  splashGlowB = ObsidianPrimary.copy(alpha = 0.22f),
  dividerColor = Color(0x3310B981),
  sliderInactiveTrack = Color(0xFF1D3D2E)
)

// Index 5: Old Classic Design (Original Navy + Electric Blue + Realme Green)
val OldClassicPalette = AppThemePalette(
  option = AppThemeOption.OLD_CLASSIC,
  background = Color(0xFF0A0D14),
  surface = Color(0xFF141926),
  surfaceElevated = Color(0xFF1D2436),
  primary = Color(0xFF3B82F6),
  secondary = Color(0xFF00D1FF),
  tertiary = Color(0xFFA78BFA),
  success = Color(0xFF22C55E),
  warning = Color(0xFFF59E0B),
  error = Color(0xFFEF4444),
  border = Color(0xFF242D42),
  specularTopLeft = Color(0x3893C5FD),
  specularBottomRight = Color(0xFF242D42),
  glossHighlight = Color(0x12FFFFFF),
  heroGradientStart = Color(0xFF182238),
  heroGradientEnd = Color(0xFF141926),
  textPrimary = Color(0xFFF3F6FC),
  textSecondary = Color(0xFF9AA5BD),
  textMuted = Color(0xFF6B7792),
  navBarContainer = Color(0xFF101522),
  splashGlowA = Color(0xFF22C55E).copy(alpha = 0.20f),
  splashGlowB = Color(0xFF3B82F6).copy(alpha = 0.22f),
  dividerColor = Color(0xFF242D42),
  sliderInactiveTrack = Color(0xFF283249)
)

// Index 6: Viral Nothing OS / Monochrome Studio OLED
val NothingMonoPalette = AppThemePalette(
  option = AppThemeOption.NOTHING_MONO,
  background = Color(0xFF000000),
  surface = Color(0xFF121214),
  surfaceElevated = Color(0xFF1C1C20),
  primary = Color(0xFFFFFFFF),
  secondary = Color(0xFFFF2D55),
  tertiary = Color(0xFFFF9F0A),
  success = Color(0xFF30D158),
  warning = Color(0xFFFF9F0A),
  error = Color(0xFFFF375F),
  border = Color(0xFF2A2A2E),
  specularTopLeft = Color(0x45FFFFFF),
  specularBottomRight = Color(0x18FFFFFF),
  glossHighlight = Color(0x12FFFFFF),
  heroGradientStart = Color(0xFF19191D),
  heroGradientEnd = Color(0xFF101012),
  textPrimary = Color(0xFFFFFFFF),
  textSecondary = Color(0xFFA1A1AA),
  textMuted = Color(0xFF71717A),
  navBarContainer = Color(0xFF0E0E10),
  splashGlowA = Color(0xFFFF2D55).copy(alpha = 0.22f),
  splashGlowB = Color(0xFFFFFFFF).copy(alpha = 0.14f),
  dividerColor = Color(0xFF26262A),
  sliderInactiveTrack = Color(0xFF2C2C32)
)

// Index 7: Viral Sunset Creator Mesh (Coral Peach + Warm Cocoa)
val SunsetCreatorPalette = AppThemePalette(
  option = AppThemeOption.SUNSET_CREATOR,
  background = Color(0xFF130D10),
  surface = Color(0xFF20161B),
  surfaceElevated = Color(0xFF2D1F25),
  primary = Color(0xFFFF6B6B),
  secondary = Color(0xFFFFB86C),
  tertiary = Color(0xFF34D399),
  success = Color(0xFF34D399),
  warning = Color(0xFFFFB86C),
  error = Color(0xFFF43F5E),
  border = Color(0xFF3D2A32),
  specularTopLeft = Color(0x4DFF9A9E),
  specularBottomRight = Color(0x22FFB86C),
  glossHighlight = Color(0x16FFCAD4),
  heroGradientStart = Color(0xFF2C1B21),
  heroGradientEnd = Color(0xFF1C1317),
  textPrimary = Color(0xFFFFF5F6),
  textSecondary = Color(0xFFD4B7BF),
  textMuted = Color(0xFF9C7B85),
  navBarContainer = Color(0xFF1A1115),
  splashGlowA = Color(0xFFFF6B6B).copy(alpha = 0.26f),
  splashGlowB = Color(0xFFFFB86C).copy(alpha = 0.20f),
  dividerColor = Color(0xFF3D2A32),
  sliderInactiveTrack = Color(0xFF422D35)
)

// Index 8: Viral Dribbble Nordic Matcha Editorial (Light)
val NordicMatchaPalette = AppThemePalette(
  option = AppThemeOption.NORDIC_MATCHA,
  background = Color(0xFFF1F4EE),
  surface = Color(0xFFFFFFFF),
  surfaceElevated = Color(0xFFE6ECE2),
  primary = Color(0xFF1D7A5F),
  secondary = Color(0xFFE05A47),
  tertiary = Color(0xFFD97706),
  success = Color(0xFF16A34A),
  warning = Color(0xFFEA580C),
  error = Color(0xFFDC2626),
  border = Color(0xFFD5DFD0),
  specularTopLeft = Color(0xFFFFFFFF),
  specularBottomRight = Color(0xFFD5DFD0),
  glossHighlight = Color(0x44FFFFFF),
  heroGradientStart = Color(0xFFFFFFFF),
  heroGradientEnd = Color(0xFFE9F0E6),
  textPrimary = Color(0xFF161C18),
  textSecondary = Color(0xFF4D5C53),
  textMuted = Color(0xFF7B8C81),
  navBarContainer = Color(0xFFFFFFFF),
  splashGlowA = Color(0xFF1D7A5F).copy(alpha = 0.18f),
  splashGlowB = Color(0xFFE05A47).copy(alpha = 0.14f),
  dividerColor = Color(0xFFD5DFD0),
  sliderInactiveTrack = Color(0xFFC9D6C3)
)

fun paletteForThemeIndex(index: Int): AppThemePalette = when (index) {
  1 -> IphoneLiquidGlassPalette
  2 -> IphoneLightFrostPalette
  3 -> CyberNeonPalette
  4 -> AuroraLightPalette
  5 -> OldClassicPalette
  6 -> NothingMonoPalette
  7 -> SunsetCreatorPalette
  8 -> NordicMatchaPalette
  else -> ClassicDarkPalette
}

val LocalAppThemePalette = compositionLocalOf { ClassicDarkPalette }

object AppTheme {
  val colors: AppThemePalette
    @Composable
    get() = LocalAppThemePalette.current
}

/**
 * Rich, layered atmospheric backdrop tailored to each theme (glass refraction, OLED mono aura, sunset mesh, or editorial warmth).
 */
@Composable
fun AppThemeBackdrop(
  palette: AppThemePalette,
  accentColor: Color,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  val bgColor by animateColorAsState(palette.background, tween(350), label = "theme_bg")

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(bgColor)
  ) {
    if (palette.isGlass && !palette.isCustomActive) {
      val infinite = rememberInfiniteTransition(label = "glass_wallpaper")
      val drift by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000), RepeatMode.Restart),
        label = "wallpaper_drift"
      )

      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val angle = (drift * 2f * PI).toFloat()

        when (palette.option) {
          AppThemeOption.IPHONE_LIQUID_GLASS -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF060B18), Color(0xFF0B142A), Color(0xFF050812))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFF38BDF8).copy(alpha = 0.34f), Color.Transparent),
                center = Offset(w * (0.20f + 0.08f * cos(angle)), h * (0.16f + 0.04f * sin(angle))),
                radius = w * 0.72f
              ),
              center = Offset(w * (0.20f + 0.08f * cos(angle)), h * (0.16f + 0.04f * sin(angle))),
              radius = w * 0.72f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFFA78BFA).copy(alpha = 0.24f), Color.Transparent),
                center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.48f + 0.06f * cos(angle))),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.82f - 0.07f * sin(angle)), h * (0.48f + 0.06f * cos(angle))),
              radius = w * 0.65f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFB7185).copy(alpha = 0.18f), Color.Transparent),
                center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.84f - 0.04f * cos(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.35f + 0.06f * sin(angle)), h * (0.84f - 0.04f * cos(angle))),
              radius = w * 0.68f
            )
          }

          AppThemeOption.IPHONE_LIGHT_FROST -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFBF6EE), Color(0xFFF1E6D5), Color(0xFFF7F1E7))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianPrimary.copy(alpha = 0.24f), Color.Transparent),
                center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
                radius = w * 0.68f
              ),
              center = Offset(w * (0.20f + 0.06f * cos(angle)), h * (0.16f + 0.03f * sin(angle))),
              radius = w * 0.68f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianSecondary.copy(alpha = 0.18f), Color.Transparent),
                center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
                radius = w * 0.62f
              ),
              center = Offset(w * (0.84f - 0.05f * sin(angle)), h * (0.50f + 0.05f * cos(angle))),
              radius = w * 0.62f
            )
          }

          AppThemeOption.CYBER_NEON -> {
            drawRect(
              brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF06110C), Color(0xFF0A1B13), Color(0xFF050D09))
              )
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianSecondary.copy(alpha = 0.26f), Color.Transparent),
                center = Offset(w * (0.18f + 0.08f * cos(angle)), h * (0.20f + 0.03f * sin(angle))),
                radius = w * 0.65f
              ),
              center = Offset(w * (0.18f + 0.08f * cos(angle)), h * (0.20f + 0.03f * sin(angle))),
              radius = w * 0.65f
            )
            drawCircle(
              brush = Brush.radialGradient(
                colors = listOf(ObsidianPrimary.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
                radius = w * 0.70f
              ),
              center = Offset(w * (0.82f - 0.06f * sin(angle)), h * 0.72f),
              radius = w * 0.70f
            )
          }

          else -> Unit
        }
      }
    } else {
      // Crisp Dribbble-style mesh glow tailored to the selected palette
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val glowA = if (palette.option == AppThemeOption.NOTHING_MONO) palette.secondary else palette.primary
        val alphaA = when {
          palette.option == AppThemeOption.NOTHING_MONO -> 0.09f
          palette.option == AppThemeOption.SUNSET_CREATOR -> 0.16f
          palette.isLight -> 0.09f
          else -> 0.11f
        }
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(glowA.copy(alpha = alphaA), Color.Transparent),
            center = Offset(w * 0.15f, h * 0.08f),
            radius = w * 0.90f
          ),
          center = Offset(w * 0.15f, h * 0.08f),
          radius = w * 0.90f
        )
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(palette.secondary.copy(alpha = if (palette.isLight) 0.07f else 0.08f), Color.Transparent),
            center = Offset(w * 0.88f, h * 0.86f),
            radius = w * 0.78f
          ),
          center = Offset(w * 0.88f, h * 0.86f),
          radius = w * 0.78f
        )
      }
    }

    content()
  }
}

/**
 * Refined Dribbble/Linear-style card lighting:
 * Uses soft surface tonal separation + subtle top specular hairline highlight instead of harsh full boxes.
 */
@Composable
fun ThemedCard(
  modifier: Modifier = Modifier,
  cornerRadius: Dp = 22.dp,
  variant: CardVariant = CardVariant.CONTROL_PANEL,
  statusColor: Color? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val palette = AppTheme.colors
  val resolvedRadius = when (variant) {
    CardVariant.HERO_PREVIEW -> 28.dp
    CardVariant.UTILITY_COMPACT -> 20.dp
    else -> cornerRadius
  }
  val shape: Shape = RoundedCornerShape(resolvedRadius)

  if (!palette.isGlass) {
    val elevationDp = when (variant) {
      CardVariant.HERO_PREVIEW -> if (palette.isLight) 10.dp else 16.dp
      CardVariant.STUDIO_CREATIVE -> if (palette.isLight) 6.dp else 10.dp
      CardVariant.STATUS_REACTIVE -> if (palette.isLight) 6.dp else 9.dp
      CardVariant.UTILITY_COMPACT -> if (palette.isLight) 4.dp else 6.dp
      CardVariant.CONTROL_PANEL -> if (palette.isLight) 5.dp else 8.dp
    }

    val topRim = if (palette.isLight) palette.border else palette.specularTopLeft
    val borderBrush = when (variant) {
      CardVariant.HERO_PREVIEW -> Brush.linearGradient(
        colors = listOf(
          palette.primary.copy(alpha = if (palette.isLight) 0.42f else 0.55f),
          palette.border.copy(alpha = 0.65f),
          palette.secondary.copy(alpha = if (palette.isLight) 0.28f else 0.36f)
        )
      )
      CardVariant.STUDIO_CREATIVE -> Brush.linearGradient(
        colors = listOf(
          palette.secondary.copy(alpha = if (palette.isLight) 0.34f else 0.42f),
          palette.border.copy(alpha = 0.55f)
        )
      )
      CardVariant.STATUS_REACTIVE -> {
        val tint = statusColor ?: palette.primary
        Brush.horizontalGradient(
          colors = listOf(tint.copy(alpha = 0.55f), palette.border.copy(alpha = 0.55f))
        )
      }
      CardVariant.UTILITY_COMPACT -> Brush.verticalGradient(
        colors = listOf(topRim, palette.border.copy(alpha = 0.45f))
      )
      CardVariant.CONTROL_PANEL -> Brush.verticalGradient(
        colors = listOf(topRim, palette.border.copy(alpha = 0.40f))
      )
    }

    val spotColor = when (variant) {
      CardVariant.HERO_PREVIEW -> palette.primary.copy(alpha = if (palette.isLight) 0.14f else 0.28f)
      CardVariant.STUDIO_CREATIVE -> palette.secondary.copy(alpha = if (palette.isLight) 0.10f else 0.18f)
      CardVariant.STATUS_REACTIVE -> (statusColor ?: palette.primary).copy(alpha = 0.18f)
      else -> Color.Black.copy(alpha = if (palette.isLight) 0.06f else 0.42f)
    }

    val surfaceModifier = when (variant) {
      CardVariant.HERO_PREVIEW -> Modifier.background(
        Brush.linearGradient(
          colors = listOf(palette.heroGradientStart, palette.heroGradientEnd)
        )
      )
      else -> Modifier.background(palette.surface)
    }

    Box(
      modifier = modifier
        .fillMaxWidth()
        .shadow(
          elevation = elevationDp,
          shape = shape,
          spotColor = spotColor,
          ambientColor = Color.Black.copy(alpha = if (palette.isLight) 0.06f else 0.36f)
        )
        .clip(shape)
        .then(surfaceModifier)
        .border(
          width = if (variant == CardVariant.HERO_PREVIEW || variant == CardVariant.STATUS_REACTIVE) 1.25.dp else 0.9.dp,
          brush = borderBrush,
          shape = shape
        )
    ) {
      when (variant) {
        CardVariant.STUDIO_CREATIVE -> {
          Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(
              modifier = Modifier
                .width(4.dp)
                .fillMaxHeight()
                .background(
                  Brush.verticalGradient(listOf(palette.secondary, palette.primary))
                )
            )
            Column(modifier = Modifier.weight(1f), content = content)
          }
        }
        CardVariant.STATUS_REACTIVE -> {
          val accent = statusColor ?: palette.primary
          Column(modifier = Modifier.fillMaxWidth()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.18f))))
            )
            Column(modifier = Modifier.fillMaxWidth(), content = content)
          }
        }
        else -> {
          Column(modifier = Modifier.fillMaxWidth(), content = content)
        }
      }
    }
  } else {
    val accentTint = statusColor ?: when (variant) {
      CardVariant.STUDIO_CREATIVE -> palette.secondary
      CardVariant.HERO_PREVIEW -> palette.primary
      else -> palette.specularBottomRight
    }
    val rimBrush = Brush.linearGradient(
      colors = listOf(
        palette.specularTopLeft,
        palette.border.copy(alpha = 0.25f),
        accentTint.copy(alpha = 0.65f)
      )
    )
    val glassSheen = Brush.verticalGradient(
      colors = listOf(
        palette.glossHighlight,
        Color.Transparent,
        palette.glossHighlight.copy(alpha = 0.08f)
      )
    )
    Box(
      modifier = modifier
        .fillMaxWidth()
        .shadow(
          elevation = when (variant) {
            CardVariant.HERO_PREVIEW -> if (palette.isLight) 14.dp else 22.dp
            else -> if (palette.isLight) 9.dp else 16.dp
          },
          shape = shape,
          spotColor = palette.primary.copy(alpha = if (palette.isLight) 0.18f else 0.28f),
          ambientColor = if (palette.isLight) Color(0x18000000) else Color(0x44000000)
        )
        .clip(shape)
        .background(palette.surface)
        .background(glassSheen)
        .border(width = 1.15.dp, brush = rimBrush, shape = shape)
    ) {
      Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
  }
}
