package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color
import androidx.test.core.app.ApplicationProvider
import com.example.data.CapsuleSettingsManager
import com.example.data.FavoriteTracksManager
import com.example.island.CallManager
import com.example.island.CompassSensorManager
import com.example.island.IslandActiveCard
import com.example.island.IslandStateManager
import com.example.island.NetworkEventType
import com.example.island.SoundMode
import com.example.island.StepCounterManager
import com.example.island.StepsState
import com.example.island.WeatherRepository
import com.example.media.AlbumColorExtractor
import com.example.media.MediaSessionHolder
import com.example.media.MediaTrackInfo
import com.example.ui.theme.withCustomOverrides
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Before
  fun resetState() {
    IslandStateManager.clearAllTransientStates()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Dynamic Capsule", appName)
  }

  @Test
  fun `test settings manager persistence with negative and positive offset`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateNotchOffsetY(-150)
    assertEquals(-150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(150)
    assertEquals(150, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(-35)
    assertEquals(-35, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateNotchOffsetY(0)
    assertEquals(0, settingsManager.settings.value.notchOffsetYDp)

    settingsManager.updateShowWhenIdle(false)
    assertFalse(settingsManager.settings.value.showWhenIdle)

    settingsManager.updateAccentColorIndex(2)
    assertEquals(2, settingsManager.settings.value.accentColorIndex)
  }

  @Test
  fun `test call state immediate termination on CALL_STATE_IDLE and decline`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // Start incoming call
    IslandStateManager.startCall("Sarah Connor", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.callState.value.isIncoming)

    // Simulate TelephonyManager reporting CALL_STATE_IDLE (call declined or ended)
    IslandStateManager.handleTelephonyState(android.telephony.TelephonyManager.CALL_STATE_IDLE)
    assertFalse("Call state must terminate immediately when phone is idle", IslandStateManager.callState.value.isActive)

    // Start another call and decline it
    IslandStateManager.startCall("John Smith", "987654321", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    IslandStateManager.declineCall(context)
    assertFalse("Call state must terminate immediately when declined", IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test estimated position bounds and stability`() {
    val now = android.os.SystemClock.elapsedRealtime()
    val track = MediaTrackInfo(
      title = "Test Song",
      artist = "Artist",
      durationMs = 200000L,
      currentPositionMs = 50000L,
      isPlaying = true,
      lastUpdateTime = now
    )

    // Position at now should be close to base
    val estimated = track.getEstimatedPositionMs()
    assertTrue(estimated in 50000L..50050L)

    // When paused, estimated position should equal currentPositionMs exactly
    val pausedTrack = track.copy(isPlaying = false)
    assertEquals(50000L, pausedTrack.getEstimatedPositionMs())
  }

  @Test
  fun `test media track info formatting`() {
    val track = MediaTrackInfo(
      title = "Far closer",
      artist = "David",
      durationMs = 236000L,
      currentPositionMs = 174000L,
      isPlaying = false
    )

    assertEquals("03:56", track.formatTime(track.durationMs))
    assertEquals("02:54", track.formatTime(track.currentPositionMs))
  }

  @Test
  fun `test demo track activation`() {
    MediaSessionHolder.startDemoTrack()
    val track = MediaSessionHolder.currentTrack.value
    assertNotNull(track)
    assertTrue(track!!.isPlaying)
    assertEquals("Realme Cyber Pulse", track.title)
    MediaSessionHolder.stopDemoTrack()
  }

  @Test
  fun `test island state manager and activity detection`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // When idle and no music
    assertFalse(IslandStateManager.hasAnyActiveActivity(null))

    // When torch is turned on
    IslandStateManager.turnOnFlashlight(context)
    assertTrue(IslandStateManager.flashlightState.value.isOn)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Turn torch off
    IslandStateManager.turnOffFlashlight(context)
    assertFalse(IslandStateManager.flashlightState.value.isOn)

    // When timer is started
    IslandStateManager.startTimer(60, "Tea Timer")
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.cancelTimer()

    // When call is active
    IslandStateManager.startCall("John Doe", "0123456789", isIncoming = true)
    assertTrue(IslandStateManager.callState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.endCall()
    assertFalse(IslandStateManager.callState.value.isActive)
  }

  @Test
  fun `test external clock timer sync and paused state activity`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    val futureEnd = System.currentTimeMillis() + 120_000L
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 120,
      targetEndTimeMs = futureEnd,
      isRunning = true,
      isStopwatch = false
    )

    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.timerState.value.isRunning)
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)
    assertEquals(IslandActiveCard.TIMER, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Simulate OEM second-by-second update: totalSeconds must remain preserved at 120
    IslandStateManager.updateExternalTimer(
      key = "0|com.google.android.deskclock|1|null|1001",
      pkg = "com.google.android.deskclock",
      title = "مؤقت المطبخ",
      remainingSeconds = 95,
      targetEndTimeMs = System.currentTimeMillis() + 95_000L,
      isRunning = true,
      isStopwatch = false
    )
    assertEquals(120, IslandStateManager.timerState.value.totalSeconds)

    // Pausing timer must keep isActive true so capsule stays visible
    IslandStateManager.toggleTimerPause()
    assertFalse(IslandStateManager.timerState.value.isRunning)
    assertTrue(IslandStateManager.timerState.value.isActive)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Removing notification clears the external timer cleanly
    IslandStateManager.cancelExternalTimer("0|com.google.android.deskclock|1|null|1001")
    assertFalse(IslandStateManager.timerState.value.isActive)
  }

  @Test
  fun `test 4-state sound mode transitions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.showRingerMode(SoundMode.VIBRATE)
    assertEquals(SoundMode.VIBRATE, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isActive)
    assertTrue(IslandStateManager.ringerState.value.isSilent)
    assertEquals(IslandActiveCard.RINGER, IslandStateManager.activeCard.value)

    IslandStateManager.showRingerMode(SoundMode.SILENT)
    assertEquals(SoundMode.SILENT, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.MUTED_DND)
    assertEquals(SoundMode.MUTED_DND, IslandStateManager.currentSoundMode.value)
    assertTrue(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.showRingerMode(SoundMode.RING)
    assertEquals(SoundMode.RING, IslandStateManager.currentSoundMode.value)
    assertFalse(IslandStateManager.ringerState.value.isSilent)

    IslandStateManager.dismissRinger()
    assertFalse(IslandStateManager.ringerState.value.isActive)
  }

  @Test
  fun `test download progress tracking and completion cleanup`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    IslandStateManager.updateDownloadProgress(
      key = "0|com.android.vending|42|null|1002",
      appName = "Google Play",
      title = "Downloading update",
      progress = 45,
      max = 100,
      indeterminate = false
    )

    assertTrue(IslandStateManager.downloadState.value.isActive)
    assertEquals(45, IslandStateManager.downloadState.value.percent)
    assertEquals(IslandActiveCard.DOWNLOAD, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.clearDownloadProgress("0|com.android.vending|42|null|1002")
    assertFalse(IslandStateManager.downloadState.value.isActive)
  }

  @Test
  fun `test navigation state and voice recorder privacy state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)

    // Google Maps Navigation (API-free notification parsing state)
    IslandStateManager.updateNavigation(
      key = "0|com.google.android.apps.maps|10|nav|100",
      pkg = "com.google.android.apps.maps",
      appName = "Maps",
      instruction = "200 م",
      distanceOrStreet = "انعطف يميناً إلى شارع الملك فهد",
      etaText = "12 دقيقة • 5 كم"
    )
    assertTrue(IslandStateManager.navigationState.value.isActive)
    assertEquals(IslandActiveCard.NAVIGATION, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.clearNavigation("0|com.google.android.apps.maps|10|nav|100")
    assertFalse(IslandStateManager.navigationState.value.isActive)

    // Voice Recorder Privacy State
    IslandStateManager.updateVoiceRecorder(
      key = "0|com.coloros.soundrecorder|5|rec|100",
      pkg = "com.coloros.soundrecorder",
      appName = "المسجل",
      title = "تسجيل صوتي",
      elapsedSeconds = 15,
      isRunning = true
    )
    assertTrue(IslandStateManager.privacyState.value.isVoiceRecorderActive)
    assertEquals("00:15", IslandStateManager.privacyState.value.formatElapsed())
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.toggleVoiceRecorderPause()
    assertFalse(IslandStateManager.privacyState.value.isRecorderRunning)

    IslandStateManager.clearVoiceRecorder("0|com.coloros.soundrecorder|5|rec|100")
    assertFalse(IslandStateManager.privacyState.value.isVoiceRecorderActive)
  }

  @Test
  fun `test dual split capsule activity switching and excluded packages persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // Test App Notification Filter persistence
    settingsManager.setPackageExcluded("com.whatsapp", true)
    assertTrue(settingsManager.settings.value.excludedPackages.contains("com.whatsapp"))
    settingsManager.clearExcludedPackages()
    assertFalse(settingsManager.settings.value.excludedPackages.contains("com.whatsapp"))

    // Test Dual Split Capsule when Music and Timer are both active
    val playingTrack = MediaTrackInfo(
      title = "Track A",
      artist = "Artist A",
      durationMs = 180000L,
      currentPositionMs = 10000L,
      isPlaying = true
    )
    IslandStateManager.startTimer(90, "Tea Timer")
    IslandStateManager.selectCard(IslandActiveCard.MUSIC)

    val settings = settingsManager.settings.value
    val primary = IslandStateManager.resolvePrimaryMiniCard(playingTrack, settings)
    val secondary = IslandStateManager.getSecondaryActiveCard(playingTrack, settings, primary)
    assertEquals(IslandActiveCard.MUSIC, primary)
    assertEquals(IslandActiveCard.TIMER, secondary)

    // Tapping secondary swaps primary to TIMER and secondary to MUSIC
    IslandStateManager.selectCard(secondary!!)
    val swappedPrimary = IslandStateManager.resolvePrimaryMiniCard(playingTrack, settings)
    val swappedSecondary = IslandStateManager.getSecondaryActiveCard(playingTrack, settings, swappedPrimary)
    assertEquals(IslandActiveCard.TIMER, swappedPrimary)
    assertEquals(IslandActiveCard.MUSIC, swappedSecondary)

    IslandStateManager.cancelTimer()
  }

  @Test
  fun `test album color extractor extracts vibrant color and falls back safely`() {
    val fallback = Color(0xFF00E676)

    // Null bitmap returns fallback
    assertEquals(fallback, AlbumColorExtractor.extractAccentColor(null, fallback))

    // Pure black bitmap returns fallback
    val blackBmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888).apply {
      eraseColor(AndroidColor.BLACK)
    }
    assertEquals(fallback, AlbumColorExtractor.extractAccentColor(blackBmp, fallback))

    // Bright crimson bitmap extracts red-dominant vibrant accent
    val redBmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888).apply {
      eraseColor(AndroidColor.rgb(230, 30, 60))
    }
    val extracted = AlbumColorExtractor.extractAccentColor(redBmp, fallback)
    assertTrue("Red channel should dominate extracted color", extracted.red > extracted.green && extracted.red > extracted.blue)
  }

  @Test
  fun `test landscape auto-hide orientation logic preserves incoming and active calls`() {
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = false, hideInLandscape = true, hasActiveCall = false))
    assertFalse(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = true, hasActiveCall = false))
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = true, hasActiveCall = true))
    assertTrue(IslandStateManager.shouldShowInOrientation(isLandscape = true, hideInLandscape = false, hasActiveCall = false))
  }

  @Test
  fun `test network alerts and new capsule settings persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateCapsuleStyleIndex(1)
    assertEquals(1, settingsManager.settings.value.capsuleStyleIndex)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DYNAMIC_ALBUM_COLORS, false)
    assertFalse(settingsManager.settings.value.enableDynamicAlbumColors)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DYNAMIC_ALBUM_COLORS, true)
    assertTrue(settingsManager.settings.value.enableDynamicAlbumColors)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_HIDE_IN_LANDSCAPE, false)
    assertFalse(settingsManager.settings.value.hideInLandscape)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_NETWORK_ALERTS, true)
    assertTrue(settingsManager.settings.value.enableNetworkAlerts)

    IslandStateManager.showNetworkAlert(
      type = NetworkEventType.WIFI_CONNECTED,
      title = "HomeWiFi",
      subtitle = "تم الاتصال بالشبكة اللاسلكية"
    )
    assertTrue(IslandStateManager.networkState.value.isActive)
    assertEquals(NetworkEventType.WIFI_CONNECTED, IslandStateManager.networkState.value.type)
    assertEquals("HomeWiFi", IslandStateManager.networkState.value.title)
    assertEquals(IslandActiveCard.NETWORK, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    IslandStateManager.dismissNetworkAlert()
    assertFalse(IslandStateManager.networkState.value.isActive)
  }

  @Test
  fun `test flashlight off leaves zero active activities without phantom privacy dot`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settings = CapsuleSettingsManager.getInstance(context).settings.value

    // Ensure clean baseline
    IslandStateManager.turnOffFlashlight(context)
    IslandStateManager.cancelTimer()
    IslandStateManager.endCall()

    // Turn flashlight ON -> should be active and renderable
    IslandStateManager.turnOnFlashlight(context)
    assertTrue(IslandStateManager.flashlightState.value.isOn)
    assertTrue(IslandStateManager.hasRenderableActivity(null, settings))

    // Turn flashlight OFF -> must immediately become inactive (Bug #1 fix)
    IslandStateManager.turnOffFlashlight(context)
    assertFalse(IslandStateManager.flashlightState.value.isOn)
    assertFalse(IslandStateManager.privacyState.value.isCameraInUse)
    assertFalse(IslandStateManager.hasRenderableActivity(null, settings))
  }

  @Test
  fun `test activityEventSeq increments on new events for auto-restore after swipe dismiss`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    IslandStateManager.turnOffFlashlight(context)

    val baselineSeq = IslandStateManager.activityEventSeq.value

    // Turning flashlight ON bumps event sequence
    IslandStateManager.turnOnFlashlight(context)
    val afterFlashOn = IslandStateManager.activityEventSeq.value
    assertTrue(afterFlashOn > baselineSeq)

    // Turning flashlight OFF does NOT trigger a re-appear event
    IslandStateManager.turnOffFlashlight(context)
    assertEquals(afterFlashOn, IslandStateManager.activityEventSeq.value)

    // Starting a new timer triggers a new event sequence so a swiped capsule auto-restores
    IslandStateManager.startTimer(120, "Focus")
    val afterTimerStart = IslandStateManager.activityEventSeq.value
    assertTrue(afterTimerStart > afterFlashOn)

    // Pausing an ongoing timer does NOT count as a new event
    IslandStateManager.toggleTimerPause()
    assertEquals(afterTimerStart, IslandStateManager.activityEventSeq.value)

    IslandStateManager.cancelTimer()
  }

  @Test
  fun `test smart media volume alert and haptic settings persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_VOLUME_ALERTS, false)
    assertFalse(settingsManager.settings.value.enableVolumeAlerts)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_VOLUME_ALERTS, true)
    assertTrue(settingsManager.settings.value.enableVolumeAlerts)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_HAPTIC, false)
    assertFalse(settingsManager.settings.value.hapticFeedback)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_HAPTIC, true)
    assertTrue(settingsManager.settings.value.hapticFeedback)

    IslandStateManager.showVolumeAlert(9, 15)
    assertTrue(IslandStateManager.volumeState.value.isActive)
    assertEquals(60, IslandStateManager.volumeState.value.percent)
    assertFalse(IslandStateManager.volumeState.value.isMuted)
    assertEquals(IslandActiveCard.VOLUME, IslandStateManager.activeCard.value)

    IslandStateManager.showVolumeAlert(0, 15)
    assertEquals(0, IslandStateManager.volumeState.value.percent)
    assertTrue(IslandStateManager.volumeState.value.isMuted)
    IslandStateManager.dismissVolumeAlert()
    assertFalse(IslandStateManager.volumeState.value.isActive)
  }

  @Test
  fun `test favorite tracks manager add toggle remove and clear persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val favManager = FavoriteTracksManager.getInstance(context)
    favManager.clearAll()
    assertTrue(favManager.favorites.value.isEmpty())

    val track = MediaTrackInfo(
      title = "Cyber Pulse",
      artist = "Dynamic Sound",
      album = "Beats",
      durationMs = 215000L,
      currentPositionMs = 10000L,
      isPlaying = true,
      packageName = "com.spotify.music",
      appName = "Spotify"
    )

    // First tap adds track to favorites
    val added = favManager.toggleFavorite(track)
    assertTrue(added)
    assertTrue(favManager.isFavorite(track))
    assertEquals(1, favManager.favorites.value.size)
    assertEquals("03:35", favManager.favorites.value.first().formatDuration())

    // Case-insensitive match verifies same track ID
    val sameTrackDifferentCase = track.copy(title = "  cyber pulse ")
    assertTrue(favManager.isFavorite(sameTrackDifferentCase))

    // Second tap removes track from favorites
    val afterSecondToggle = favManager.toggleFavorite(track)
    assertFalse(afterSecondToggle)
    assertFalse(favManager.isFavorite(track))
    assertTrue(favManager.favorites.value.isEmpty())

    // Add again and clearAll
    favManager.toggleFavorite(track)
    assertEquals(1, favManager.favorites.value.size)
    favManager.clearAll()
    assertTrue(favManager.favorites.value.isEmpty())
  }

  @Test
  fun `test audio output summary returns valid system route string`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val summary = IslandStateManager.getAudioOutputSummary(context)
    assertTrue(summary.isNotBlank())
  }

  @Test
  fun `test animation preferences and alarm sync persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    settingsManager.updateOpenAnimationIndex(3)
    assertEquals(3, settingsManager.settings.value.openAnimationIndex)

    settingsManager.updateAuraAnimationIndex(1)
    assertEquals(1, settingsManager.settings.value.auraAnimationIndex)

    settingsManager.updateVisualizerStyleIndex(2)
    assertEquals(2, settingsManager.settings.value.visualizerStyleIndex)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_ALARM_SYNC, false)
    assertFalse(settingsManager.settings.value.enableAlarmSync)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_ALARM_SYNC, true)
    assertTrue(settingsManager.settings.value.enableAlarmSync)
  }

  @Test
  fun `test sleep timer lifecycle and next alarm refresh`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val initialSeq = IslandStateManager.activityEventSeq.value

    IslandStateManager.startSleepTimer(15)
    assertTrue(IslandStateManager.sleepTimerState.value.isActive)
    assertEquals(900, IslandStateManager.sleepTimerState.value.remainingSeconds)
    assertEquals(IslandActiveCard.SLEEP_TIMER, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))
    assertTrue(IslandStateManager.activityEventSeq.value > initialSeq)

    IslandStateManager.cancelSleepTimer()
    assertFalse(IslandStateManager.sleepTimerState.value.isActive)
    assertEquals(0, IslandStateManager.sleepTimerState.value.remainingSeconds)

    IslandStateManager.refreshNextAlarm(context)
    assertNotNull(IslandStateManager.nextAlarmState.value)
  }

  @Test
  fun `test weather Open-Meteo parser and WMO Arabic severity mapping`() {
    val (clearLabel, clearWarn) = WeatherRepository.mapWmoCodeToArabic(0, tempC = 25)
    assertEquals("سماء صافية", clearLabel)
    assertFalse(clearWarn)

    val (stormLabel, stormWarn) = WeatherRepository.mapWmoCodeToArabic(95, tempC = 18)
    assertEquals("عاصفة رعدية", stormLabel)
    assertTrue(stormWarn)

    val (_, heatWarn) = WeatherRepository.mapWmoCodeToArabic(0, tempC = 46)
    assertTrue(heatWarn)

    val sampleJson = """
      {
        "current": {
          "temperature_2m": 28.4,
          "relative_humidity_2m": 42,
          "is_day": 1,
          "weather_code": 2,
          "wind_speed_10m": 14.6
        },
        "daily": {
          "sunrise": ["2026-05-12T05:18"],
          "sunset": ["2026-05-12T18:42"]
        },
        "hourly": {
          "time": [
            "2026-05-12T00:00",
            "2026-05-12T06:00",
            "2026-05-12T12:00",
            "2026-05-12T15:00",
            "2026-05-12T18:00",
            "2026-05-12T21:00"
          ],
          "temperature_2m": [20.1, 22.0, 28.4, 30.2, 27.1, 24.0],
          "weather_code": [0, 1, 2, 2, 3, 61]
        }
      }
    """.trimIndent()

    val parsed = WeatherRepository.parseOpenMeteoResponse(sampleJson, "الرياض")
    assertTrue(parsed.isLoaded)
    assertEquals("الرياض", parsed.cityName)
    assertEquals(28, parsed.temperatureC)
    assertEquals(42, parsed.humidityPct)
    assertEquals(15, parsed.windSpeedKmh)
    assertEquals("غائم جزئياً", parsed.conditionAr)
    assertEquals("05:18", parsed.sunriseText)
    assertEquals("18:42", parsed.sunsetText)
    assertFalse(parsed.isWarning)
    assertTrue(parsed.hourlyForecast.isNotEmpty())
    assertTrue(parsed.hourlyForecast.size <= 6)
    assertTrue(parsed.hourlyForecast.all { it.hourLabel.contains(":") })
  }

  @Test
  fun `test step counter accumulation, pause, reboot banking, and reset`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    var latestState = StepsState()
    var lastMilestone = false
    val manager = StepCounterManager(context) { st, hit ->
      latestState = st
      lastMilestone = hit
    }
    manager.resetToday()
    manager.setDailyGoal(6000)
    manager.setPaused(false)

    val baseTime = System.currentTimeMillis()
    // Initial reading sets baseline = 1000f -> 0 steps
    manager.processRawSensorReading(1000f, baseTime)
    assertEquals(0, latestState.steps)
    assertFalse(lastMilestone)

    // Walk 1200 steps -> 1200 steps & ~0.9144 km
    manager.processRawSensorReading(2200f, baseTime + 5_000L)
    assertEquals(1200, latestState.steps)
    assertTrue(lastMilestone)
    assertEquals((1200 * 0.762f) / 1000f, latestState.distanceKm, 0.01f)

    // Pause -> additional raw steps must NOT increment today's steps
    manager.setPaused(true)
    manager.processRawSensorReading(2500f, baseTime + 8_000L)
    assertEquals(1200, latestState.steps)

    // Resume and walk 300 more steps -> 1500 total
    manager.setPaused(false)
    manager.processRawSensorReading(2800f, baseTime + 11_000L)
    assertEquals(1500, latestState.steps)

    // Device reboot resets raw sensor to 200f (< 2800f): 1500 carried + 200 new = 1700
    manager.processRawSensorReading(200f, baseTime + 15_000L)
    assertEquals(1700, latestState.steps)

    // Reset clears today's steps
    manager.resetToday()
    assertEquals(0, latestState.steps)
  }

  @Test
  fun `test compass cardinal directions across all angles`() {
    assertEquals("شمال", CompassSensorManager.azimuthToArabicDirection(0f))
    assertEquals("شمال", CompassSensorManager.azimuthToArabicDirection(355f))
    assertEquals("شمال شرق", CompassSensorManager.azimuthToArabicDirection(45f))
    assertEquals("شرق", CompassSensorManager.azimuthToArabicDirection(90f))
    assertEquals("جنوب شرق", CompassSensorManager.azimuthToArabicDirection(135f))
    assertEquals("جنوب", CompassSensorManager.azimuthToArabicDirection(180f))
    assertEquals("جنوب غرب", CompassSensorManager.azimuthToArabicDirection(225f))
    assertEquals("غرب", CompassSensorManager.azimuthToArabicDirection(270f))
    assertEquals("شمال غرب", CompassSensorManager.azimuthToArabicDirection(315f))
    assertEquals("غرب", CompassSensorManager.azimuthToArabicDirection(-90f))
  }

  @Test
  fun `test bluetooth battery, pomodoro focus lifecycle, and new feature settings persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // Persist new feature settings
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_STEPS_COUNTER, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_PIN_STEPS, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_WEATHER_ALERTS, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_PIN_WEATHER, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_COMPASS, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_FOCUS_TIMER, true)
    settingsManager.updateWeatherCityQuery("جدة")

    assertTrue(settingsManager.settings.value.enableStepsCounter)
    assertTrue(settingsManager.settings.value.pinStepsInCapsule)
    assertTrue(settingsManager.settings.value.enableWeatherAlerts)
    assertTrue(settingsManager.settings.value.pinWeatherInCapsule)
    assertTrue(settingsManager.settings.value.enableCompass)
    assertTrue(settingsManager.settings.value.enableFocusTimer)
    assertEquals("جدة", settingsManager.settings.value.weatherCityQuery)

    // Bluetooth connection with battery level
    IslandStateManager.showBluetoothConnected("Realme Buds Air 6", 82)
    assertTrue(IslandStateManager.bluetoothState.value.isConnected)
    assertEquals("Realme Buds Air 6", IslandStateManager.bluetoothState.value.deviceName)
    assertEquals(82, IslandStateManager.bluetoothState.value.batteryPct)

    // Pomodoro Focus lifecycle
    IslandStateManager.startFocusSession(25, isBreak = false)
    assertTrue(IslandStateManager.focusState.value.isActive)
    assertTrue(IslandStateManager.focusState.value.isRunning)
    assertEquals(25 * 60, IslandStateManager.focusState.value.remainingSeconds)
    assertEquals(IslandActiveCard.FOCUS, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    IslandStateManager.toggleFocusPause()
    assertFalse(IslandStateManager.focusState.value.isRunning)

    IslandStateManager.cancelFocusSession()
    assertFalse(IslandStateManager.focusState.value.isActive)
    assertEquals(0, IslandStateManager.focusState.value.remainingSeconds)
  }

  @Test
  fun `test app themes persistence including Obsidian Amber Sandstone Light and Glass`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // Obsidian Amber & Jade baseline (index 0 — zero blue, zero purple)
    settingsManager.updateAppThemeIndex(0)
    settingsManager.updateCapsuleStyleIndex(0)
    assertEquals(0, settingsManager.settings.value.appThemeIndex)
    assertFalse(settingsManager.settings.value.isLiquidGlassCapsule)
    val obsidianDark = com.example.ui.theme.paletteForThemeIndex(0)
    assertFalse(obsidianDark.isGlass)
    assertFalse(obsidianDark.isLight)
    assertEquals(Color(0xFF0E0C0A), obsidianDark.background)
    assertEquals(Color(0xFF181512), obsidianDark.surface)
    assertEquals(Color(0xFF241F1A), obsidianDark.surfaceElevated)
    assertEquals(Color(0xFFF59E0B), obsidianDark.primary)
    assertEquals(Color(0xFF10B981), obsidianDark.secondary)
    assertEquals(Color(0xFFFB7185), obsidianDark.tertiary)
    assertEquals(Color(0xFF22C55E), obsidianDark.success)
    assertEquals(Color(0xFFF97316), obsidianDark.warning)
    assertEquals(Color(0xFFEF4444), obsidianDark.error)

    // Smoked Titanium Glass (index 1) activates glass capsule & dark glass palette
    settingsManager.updateAppThemeIndex(1)
    assertEquals(1, settingsManager.settings.value.appThemeIndex)
    assertTrue(settingsManager.settings.value.isLiquidGlassCapsule)
    val glassPalette = com.example.ui.theme.paletteForThemeIndex(1)
    assertTrue(glassPalette.isGlass)
    assertFalse(glassPalette.isLight)

    // Light Frost switches to light glass palette with dark readable text
    settingsManager.updateAppThemeIndex(2)
    val lightGlassPalette = com.example.ui.theme.paletteForThemeIndex(2)
    assertTrue(lightGlassPalette.isGlass)
    assertTrue(lightGlassPalette.isLight)
    assertTrue(lightGlassPalette.textPrimary.red < 0.2f)

    // Sandstone Ivory Light Mode (index 4) provides clean non-glass warm light tokens
    settingsManager.updateAppThemeIndex(4)
    assertEquals(4, settingsManager.settings.value.appThemeIndex)
    val sandstoneLight = com.example.ui.theme.paletteForThemeIndex(4)
    assertFalse(sandstoneLight.isGlass)
    assertTrue(sandstoneLight.isLight)
    assertEquals(Color(0xFFF5EFE4), sandstoneLight.background)
    assertTrue(sandstoneLight.textPrimary.red < 0.2f)

    // Classic Old Design (index 5) restored cleanly for users who prefer it
    settingsManager.updateAppThemeIndex(5)
    assertEquals(5, settingsManager.settings.value.appThemeIndex)
    val oldClassic = com.example.ui.theme.paletteForThemeIndex(5)
    assertFalse(oldClassic.isLight)
    assertEquals(Color(0xFF0A0D14), oldClassic.background)

    // Viral Social-Media Themes (Nothing Mono index 6, Sunset Coral index 7, Nordic Matcha index 8)
    settingsManager.updateAppThemeIndex(6)
    val nothingMono = com.example.ui.theme.paletteForThemeIndex(6)
    assertEquals(Color(0xFF000000), nothingMono.background)
    assertEquals(Color(0xFFFF2D55), nothingMono.secondary)

    settingsManager.updateAppThemeIndex(7)
    val sunset = com.example.ui.theme.paletteForThemeIndex(7)
    assertEquals(Color(0xFFFF6B6B), sunset.primary)

    settingsManager.updateAppThemeIndex(8)
    val matcha = com.example.ui.theme.paletteForThemeIndex(8)
    assertTrue(matcha.isLight)
    assertTrue(matcha.textPrimary.red < 0.2f)

    // Apple Blue accent index 5 still resolves cleanly if explicitly chosen
    settingsManager.updateAccentColorIndex(5)
    assertEquals(Color(0xFF0A84FF), settingsManager.settings.value.accentColor)

    // Out-of-bounds theme index clamps cleanly to max index 8
    settingsManager.updateAppThemeIndex(99)
    assertEquals(8, settingsManager.settings.value.appThemeIndex)
  }

  @Test
  fun `test capsule 6 themes, opaque vs transparent opacity, and free custom color studio overrides`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // 1. Capsule 6 themes (0..5) and clamping
    settingsManager.updateCapsuleStyleIndex(4)
    assertEquals(4, settingsManager.settings.value.capsuleStyleIndex)
    settingsManager.updateCapsuleStyleIndex(5)
    assertEquals(5, settingsManager.settings.value.capsuleStyleIndex)
    settingsManager.updateCapsuleStyleIndex(99)
    assertEquals(5, settingsManager.settings.value.capsuleStyleIndex)

    // 2. Opaque vs Transparent & opacity clamping (40..100)
    settingsManager.updateAppThemeIndex(1)
    settingsManager.updateCapsuleTransparent(false)
    assertFalse(settingsManager.settings.value.capsuleTransparent)
    // Solid opaque mode disables liquid glass translucency even on glass app theme
    assertFalse(settingsManager.settings.value.isLiquidGlassCapsule)

    settingsManager.updateCapsuleTransparent(true)
    assertTrue(settingsManager.settings.value.capsuleTransparent)
    assertTrue(settingsManager.settings.value.isLiquidGlassCapsule)

    settingsManager.updateCapsuleOpacityPercent(62)
    assertEquals(62, settingsManager.settings.value.capsuleOpacityPercent)
    settingsManager.updateCapsuleOpacityPercent(10)
    assertEquals(40, settingsManager.settings.value.capsuleOpacityPercent)

    // 3. Free Custom Colors Studio overrides & palette composition
    settingsManager.resetAllCustomColors()
    assertFalse(settingsManager.settings.value.useCustomColors)

    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.BACKGROUND, android.graphics.Color.rgb(245, 245, 250))
    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.SURFACE, android.graphics.Color.WHITE)
    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.PRIMARY, android.graphics.Color.rgb(255, 60, 100))
    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.SECONDARY, android.graphics.Color.rgb(10, 180, 140))
    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.TEXT_PRIMARY, android.graphics.Color.rgb(20, 20, 25))
    settingsManager.updateCustomColor(com.example.data.CustomColorSlot.CAPSULE_BG, android.graphics.Color.rgb(18, 24, 40))

    val s = settingsManager.settings.value
    assertTrue(s.useCustomColors)
    assertEquals(Color(255, 60, 100), s.effectiveAccentColor)
    assertEquals(android.graphics.Color.rgb(18, 24, 40), s.customCapsuleBgColor)

    val customPalette = com.example.ui.theme.paletteForThemeIndex(0).withCustomOverrides(s)
    assertTrue(customPalette.isCustomActive)
    assertTrue(customPalette.isLight) // luminance auto-detected from light custom background
    assertEquals(Color(245, 245, 250), customPalette.background)
    assertEquals(Color.White, customPalette.surface)
    assertEquals(Color(255, 60, 100), customPalette.primary)
    assertEquals(Color(10, 180, 140), customPalette.secondary)
    assertEquals(Color(20, 20, 25), customPalette.textPrimary)

    // Reset all restores preset palette cleanly
    settingsManager.resetAllCustomColors()
    assertFalse(settingsManager.settings.value.useCustomColors)
    val restored = com.example.ui.theme.paletteForThemeIndex(0).withCustomOverrides(settingsManager.settings.value)
    assertFalse(restored.isCustomActive)
    assertEquals(Color(0xFF0E0C0A), restored.background)
  }

  @Test
  fun `test showWeatherCard selects WEATHER tab even while loading`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    IslandStateManager.showWeatherCard(context)
    assertEquals(IslandActiveCard.WEATHER, IslandStateManager.activeCard.value)
  }

  @Test
  fun `test step reward stars tiers, cumulative total, and reset reconciliation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    var latestState = StepsState()
    var lastHit = false
    val manager = StepCounterManager(context) { st, hit ->
      latestState = st
      lastHit = hit
    }
    manager.resetToday()
    manager.setDailyGoal(4000) // Tiers: 1000, 2000, 3000, 4000, 5000
    manager.setPaused(false)

    val now = System.currentTimeMillis()
    manager.processRawSensorReading(100f, now)
    assertEquals(0, latestState.starsToday)
    assertEquals(1000, latestState.nextStarStepsRemaining)

    // Walk 1000 steps -> unlocks 1★
    manager.processRawSensorReading(1100f, now + 3_000L)
    assertEquals(1, latestState.starsToday)
    assertTrue(latestState.totalRewardStars >= 1)
    assertTrue(lastHit)
    assertEquals(1000, latestState.nextStarStepsRemaining)

    // Walk to 5100 steps -> unlocks all 5★
    manager.processRawSensorReading(5200f, now + 8_000L)
    assertEquals(5, latestState.starsToday)
    assertTrue(latestState.totalRewardStars >= 5)
    assertEquals(0, latestState.nextStarStepsRemaining)
    assertTrue(latestState.recentHistory.isNotEmpty())

    // Resetting today removes today's unbanked stars without leaving negative total
    val totalBeforeReset = latestState.totalRewardStars
    manager.resetToday()
    assertEquals(0, latestState.starsToday)
    assertEquals((totalBeforeReset - 5).coerceAtLeast(0), latestState.totalRewardStars)
  }

  @Test
  fun `test weather geocoding suggestions parser and city select rename delete persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    val geoJson = """
      {
        "results": [
          {
            "name": "الرياض",
            "latitude": 24.6877,
            "longitude": 46.7219,
            "country": "المملكة العربية السعودية",
            "admin1": "منطقة الرياض"
          },
          {
            "name": "الرياض",
            "latitude": 24.6877,
            "longitude": 46.7219,
            "country": "المملكة العربية السعودية",
            "admin1": "منطقة الرياض"
          },
          {
            "name": "جنزور",
            "latitude": 32.8172,
            "longitude": 13.0086,
            "country": "ليبيا",
            "admin1": "طرابلس"
          }
        ]
      }
    """.trimIndent()

    val suggestions = WeatherRepository.parseGeocodingSuggestions(geoJson)
    assertEquals(2, suggestions.size) // deduplicates duplicate Riyadh entry
    assertEquals("الرياض", suggestions[0].name)
    assertEquals("منطقة الرياض • المملكة العربية السعودية", suggestions[0].displaySubtitle())
    assertEquals("جنزور", suggestions[1].name)

    // Selecting exact suggestion saves query + exact coordinates
    val janzour = suggestions[1]
    settingsManager.updateWeatherCitySelection(
      query = janzour.name,
      lat = janzour.latitude,
      lon = janzour.longitude
    )
    assertTrue(settingsManager.settings.value.hasCustomWeatherCity)
    assertEquals("جنزور", settingsManager.settings.value.weatherCityQuery)
    assertEquals(32.8172, settingsManager.settings.value.weatherCityLat!!, 0.0001)
    assertEquals(13.0086, settingsManager.settings.value.weatherCityLon!!, 0.0001)

    // Renaming display alias preserves real coordinates
    settingsManager.renameWeatherCityDisplay("مدينتي جنزور")
    assertEquals("مدينتي جنزور", settingsManager.settings.value.weatherCityDisplayAlias)
    assertEquals(32.8172, settingsManager.settings.value.weatherCityLat!!, 0.0001)

    // Deleting city clears query, alias, and coordinates cleanly
    settingsManager.clearWeatherCity()
    assertFalse(settingsManager.settings.value.hasCustomWeatherCity)
    assertEquals("", settingsManager.settings.value.weatherCityQuery)
    assertEquals("", settingsManager.settings.value.weatherCityDisplayAlias)
    assertEquals(null, settingsManager.settings.value.weatherCityLat)
    assertEquals(null, settingsManager.settings.value.weatherCityLon)
  }

  @Test
  fun `test delivery tracking, swipe-up activity cycling, and football settings persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    IslandStateManager.initialize(context)
    val settingsManager = CapsuleSettingsManager.getInstance(context)

    // Delivery & Football settings persistence
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DELIVERY_ALERTS, false)
    assertFalse(settingsManager.settings.value.enableDeliveryAlerts)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DELIVERY_ALERTS, true)
    assertTrue(settingsManager.settings.value.enableDeliveryAlerts)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_FOOTBALL_SCORES, false)
    assertFalse(settingsManager.settings.value.enableFootballScores)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_FOOTBALL_SCORES, true)
    assertTrue(settingsManager.settings.value.enableFootballScores)

    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_PIN_FOOTBALL, true)
    assertTrue(settingsManager.settings.value.pinFootballInCapsule)
    settingsManager.updateFootballLeagueCode("eng.1")
    assertEquals("eng.1", settingsManager.settings.value.footballLeagueCode)

    // Delivery tracking updates and notification-removal cleanup
    IslandStateManager.updateDeliveryOrder(
      key = "0|com.talabat|99|order|100",
      pkg = "com.talabat",
      appName = "Talabat",
      statusTitle = "المندوب في الطريق إليك",
      detailText = "باقٍ محطتان",
      etaText = "6 د",
      progressPct = 78
    )
    assertTrue(IslandStateManager.deliveryState.value.isActive)
    assertEquals("Talabat", IslandStateManager.deliveryState.value.appName)
    assertEquals(IslandActiveCard.DELIVERY, IslandStateManager.activeCard.value)
    assertTrue(IslandStateManager.hasAnyActiveActivity(null))

    // Swipe-up cycling with Music playing switches from DELIVERY to another active/enabled card
    val track = MediaTrackInfo(
      title = "Live Song",
      artist = "Artist",
      durationMs = 180000L,
      currentPositionMs = 10000L,
      isPlaying = true
    )
    val nextAfterMusic = IslandStateManager.cycleToNextCard(
      trackInfo = track,
      settings = settingsManager.settings.value,
      fromCard = IslandActiveCard.MUSIC
    )
    assertEquals(IslandActiveCard.DELIVERY, nextAfterMusic)
    assertEquals(IslandActiveCard.DELIVERY, IslandStateManager.resolvePrimaryMiniCard(track, settingsManager.settings.value))

    IslandStateManager.clearDeliveryOrder("0|com.talabat|99|order|100")
    assertFalse(IslandStateManager.deliveryState.value.isActive)
  }

  @Test
  fun `test football scoreboard parser sorts live matches first and handles halftime`() {
    val espnSample = """
      {
        "events": [
          {
            "id": "m1",
            "date": "2026-11-22T18:00Z",
            "competitions": [{
              "status": {
                "displayClock": "90'",
                "type": { "state": "post", "shortDetail": "FT" }
              },
              "competitors": [
                { "homeAway": "home", "score": "2", "team": { "shortDisplayName": "Arsenal" } },
                { "homeAway": "away", "score": "1", "team": { "shortDisplayName": "Chelsea" } }
              ]
            }]
          },
          {
            "id": "m2",
            "date": "2026-11-22T20:00Z",
            "competitions": [{
              "status": {
                "displayClock": "67'",
                "type": { "state": "in", "shortDetail": "67'" }
              },
              "competitors": [
                {
                  "homeAway": "home",
                  "score": "3",
                  "team": {
                    "shortDisplayName": "Real Madrid",
                    "abbreviation": "RMA",
                    "logos": [{ "href": "http://a.espncdn.com/i/teamlogos/soccer/500/86.png" }]
                  }
                },
                {
                  "homeAway": "away",
                  "score": "2",
                  "team": {
                    "shortDisplayName": "Barcelona",
                    "abbreviation": "BAR",
                    "logo": "https://a.espncdn.com/i/teamlogos/soccer/500/83.png"
                  }
                }
              ]
            }]
          },
          {
            "id": "m3",
            "date": "2026-11-22T20:00Z",
            "competitions": [{
              "status": {
                "displayClock": "45'",
                "type": { "state": "in", "shortDetail": "HT" }
              },
              "competitors": [
                { "homeAway": "home", "score": "1", "team": { "shortDisplayName": "Liverpool" } },
                { "homeAway": "away", "score": "1", "team": { "shortDisplayName": "Man City" } }
              ]
            }]
          }
        ]
      }
    """.trimIndent()

    val parsed = com.example.island.FootballRepository.parseEspnScoreboardJson(
      jsonStr = espnSample,
      leagueCode = "eng.1",
      leagueNameAr = "الإنجليزي"
    )
    assertTrue(parsed.isLoaded)
    assertTrue(parsed.isAlertActive)
    assertEquals(3, parsed.matches.size)
    // Live matches prioritized before finished
    assertEquals("Real Madrid", parsed.matches[0].homeTeam)
    assertTrue(parsed.matches[0].isLive)
    assertEquals("67'", parsed.matches[0].minuteOrStatus)
    assertEquals("https://a.espncdn.com/i/teamlogos/soccer/500/86.png", parsed.matches[0].homeLogoUrl)
    assertEquals("https://a.espncdn.com/i/teamlogos/soccer/500/83.png", parsed.matches[0].awayLogoUrl)
    assertEquals("RMA", parsed.matches[0].homeAbbrev)
    assertEquals("BAR", parsed.matches[0].awayAbbrev)
    assertEquals("LI", parsed.matches[1].homeAbbrev)
    assertEquals("MA", parsed.matches[1].awayAbbrev)
    assertEquals("استراحة", parsed.matches[1].minuteOrStatus)
    assertEquals("انتهت", parsed.matches[2].minuteOrStatus)
    assertTrue(parsed.matches[2].isFinished)
  }

  @Test
  fun `test manifest declares SYSTEM_ALERT_WINDOW and OverlayCapsuleService`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    @Suppress("DEPRECATION")
    val pkgInfo = context.packageManager.getPackageInfo(
      context.packageName,
      android.content.pm.PackageManager.GET_PERMISSIONS or android.content.pm.PackageManager.GET_SERVICES
    )
    val perms = pkgInfo.requestedPermissions?.toList().orEmpty()
    assertTrue("SYSTEM_ALERT_WINDOW must be declared in AndroidManifest.xml", perms.contains(android.Manifest.permission.SYSTEM_ALERT_WINDOW))
    val services = pkgInfo.services?.map { it.name }.orEmpty()
    assertTrue("OverlayCapsuleService must be registered in AndroidManifest.xml", services.any { it.endsWith("OverlayCapsuleService") })
  }

  @Test
  fun `test football live clock ticking merge and Goal Stopped Halftime FullTime event detection`() {
    val baseMatch = com.example.island.FootballMatchItem(
      id = "match_100",
      leagueNameAr = "دوري الأبطال",
      homeTeam = "Real Madrid",
      awayTeam = "Bayern",
      homeScore = 1,
      awayScore = 1,
      minuteOrStatus = "67'",
      isLive = true,
      isFinished = false,
      matchPhase = com.example.island.FootballMatchPhase.LIVE_PLAY,
      clockSeconds = 67 * 60 + 25,
      serverClockSeconds = 67 * 60 + 18,
      isStoppageTime = false
    )
    assertEquals("67:25", baseMatch.formattedLiveTime())

    // When fresh poll returns same serverClockSeconds, keep smooth local 67:25 (+7s <= +12s cap)
    val staleServerPoll = baseMatch.copy(clockSeconds = 67 * 60 + 18, serverClockSeconds = 67 * 60 + 18)
    val merged = com.example.island.FootballRepository.mergeLiveClocks(listOf(baseMatch), listOf(staleServerPoll))
    assertEquals(67 * 60 + 25, merged.first().clockSeconds)

    // Whole-minute displayClock (e.g. "22'" with clock=1320.0) should NOT fabricate synthetic ticking seconds
    val wholeMinuteJson = """
      {
        "events": [{
          "id": "match_whole",
          "competitions": [{
            "status": {
              "clock": 1320.0,
              "displayClock": "22'",
              "type": { "state": "in", "shortDetail": "22'" }
            },
            "competitors": [
              { "homeAway": "home", "score": "0", "team": { "shortDisplayName": "Team A" } },
              { "homeAway": "away", "score": "0", "team": { "shortDisplayName": "Team B" } }
            ]
          }]
        }]
      }
    """.trimIndent()
    val wholeParsed = com.example.island.FootballRepository.parseEspnScoreboardJson(wholeMinuteJson, "eng.1", "الإنجليزي")
    assertEquals(-1, wholeParsed.matches[0].clockSeconds)
    assertEquals("22'", wholeParsed.matches[0].formattedLiveTime())

    // 1. Goal event detection
    val goalScoredMatch = baseMatch.copy(homeScore = 2)
    val goalEvent = com.example.island.FootballRepository.detectMatchEvent(
      previous = listOf(baseMatch),
      fresh = listOf(goalScoredMatch),
      preferredMatchId = "match_100"
    )
    assertNotNull(goalEvent)
    assertEquals(com.example.island.FootballEventType.GOAL, goalEvent?.type)
    assertEquals(com.example.island.FootballScoringSide.HOME, goalEvent?.scoringSide)
    assertEquals("هدف!", goalEvent?.titleAr)

    // 2. Stopped / Suspended match phase + event detection via JSON parser
    val suspendedJson = """
      {
        "events": [{
          "id": "match_100",
          "competitions": [{
            "status": {
              "displayClock": "71'",
              "type": { "state": "in", "name": "STATUS_SUSPENDED", "shortDetail": "Susp" }
            },
            "competitors": [
              { "homeAway": "home", "score": "2", "team": { "shortDisplayName": "Real Madrid" } },
              { "homeAway": "away", "score": "1", "team": { "shortDisplayName": "Bayern" } }
            ]
          }]
        }]
      }
    """.trimIndent()
    val parsedSuspended = com.example.island.FootballRepository.parseEspnScoreboardJson(suspendedJson, "uefa.champions", "دوري الأبطال")
    assertEquals(com.example.island.FootballMatchPhase.STOPPED, parsedSuspended.matches[0].matchPhase)
    val stoppedEvent = com.example.island.FootballRepository.detectMatchEvent(
      previous = listOf(goalScoredMatch),
      fresh = parsedSuspended.matches,
      preferredMatchId = "match_100"
    )
    assertEquals(com.example.island.FootballEventType.STOPPED, stoppedEvent?.type)

    // 3. Halftime event detection
    val halftimeMatch = baseMatch.copy(matchPhase = com.example.island.FootballMatchPhase.HALFTIME, minuteOrStatus = "استراحة")
    val halftimeEvent = com.example.island.FootballRepository.detectMatchEvent(
      previous = listOf(baseMatch),
      fresh = listOf(halftimeMatch),
      preferredMatchId = "match_100"
    )
    assertEquals(com.example.island.FootballEventType.HALFTIME, halftimeEvent?.type)

    // 4. Full-Time event detection & verify side capsule hides when match is finished
    val fullTimeMatch = goalScoredMatch.copy(
      matchPhase = com.example.island.FootballMatchPhase.FINISHED,
      isLive = false,
      isFinished = true,
      minuteOrStatus = "انتهت"
    )
    val fullTimeEvent = com.example.island.FootballRepository.detectMatchEvent(
      previous = listOf(goalScoredMatch),
      fresh = listOf(fullTimeMatch),
      preferredMatchId = "match_100"
    )
    assertEquals(com.example.island.FootballEventType.FULL_TIME, fullTimeEvent?.type)
  }

  @Test
  fun `test secondary side capsule hides football when current match is finished`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = CapsuleSettingsManager.getInstance(context)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_FOOTBALL_SCORES, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_PIN_FOOTBALL, true)
    settingsManager.toggleFeature(CapsuleSettingsManager.KEY_DUAL_CAPSULE, true)

    val track = com.example.media.MediaTrackInfo(
      packageName = "com.spotify.music",
      title = "Track",
      artist = "Artist",
      durationMs = 180000L,
      currentPositionMs = 10000L,
      isPlaying = true
    )

    // Inject a finished match into footballState via reflection on _footballState
    val finishedState = com.example.island.FootballState(
      isLoaded = true,
      isAlertActive = false,
      matches = listOf(
        com.example.island.FootballMatchItem(
          id = "done_1",
          homeTeam = "Team A",
          awayTeam = "Team B",
          homeScore = 2,
          awayScore = 1,
          minuteOrStatus = "انتهت",
          isLive = false,
          isFinished = true,
          matchPhase = com.example.island.FootballMatchPhase.FINISHED
        )
      )
    )
    val field = IslandStateManager::class.java.getDeclaredField("_footballState")
    field.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    val flow = field.get(IslandStateManager) as kotlinx.coroutines.flow.MutableStateFlow<com.example.island.FootballState>
    val previous = flow.value
    try {
      flow.value = finishedState
      val secondary = IslandStateManager.getSecondaryActiveCard(
        trackInfo = track,
        settings = settingsManager.settings.value,
        primaryCard = IslandActiveCard.MUSIC
      )
      assertTrue(secondary != IslandActiveCard.FOOTBALL)
    } finally {
      flow.value = previous
    }
  }
}
